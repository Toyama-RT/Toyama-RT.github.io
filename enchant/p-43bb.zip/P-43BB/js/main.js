enchant(); // おまじない  簡易会話装置のサンプル

enchant.Sound.enabledInMobileSafari = true;

if(location.protocol == 'file:'){
    enchant.ENV.USE_WEBAUDIO = false;
    console.log('1');
}

window.onload = function() {
    var Rectangle = enchant.Class.create({
        initialize: function(x, y, width, height) {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
        },
        right: {
            get: function() {
                return this.x + this.width;
            }
        },
        bottom: {
            get: function() {
                return this.y + this.height;
            }
        }
    });      // 行の終わりには、;(セミコロン)をつけます。

    var game_ = new Game(window.innerWidth  , window.innerHeight  ); // 本体を準備すると同時に、表示される領域の大きさを設定しています。
    var wiw = window.innerWidth;  //モニター表示範囲幅
    var wih = window.innerHeight; // モニター表示範囲高
    var scx = wiw * 1.8 / 1280; // 文字キー幅の係数
    var scy = wih * 1.8 / 1024;　// 文字キー高さ係数

    game_.fps = 30; // frames(フレーム) per(毎) second(秒): 進行スピードを設定しています。
    game_.preload('kotoba1.gif', 'kotoba1.mp3', 'kotoba2.gif', 'kotoba2.mp3', 'kotoba3.gif', 'kotoba3.mp3', 'kotoba4.gif', 'kotoba4.mp3', 'jump.mp3', 'gameover.mp3'); // pre(前)-load(読み込み): ゲームに使う素材を予め読み込んでおきます。

    game_.onload = function() { // 準備が整ったらメインの処理を実行します。
        game_.assets['gameover.mp3'].play();
	//表示する画像の設定
        var word1 = new Sprite(200, 50);  // word1というスプライト(操作可能な画像)を準備すると同時に、スプライトの表示される領域の大きさを設定しています。
        var word2 = new Sprite(200, 50);  // word2という　以下同文。
        var word3 = new Sprite(200, 50);  // word3という　以下同文。
        var word4 = new Sprite(200, 50);  // word4という　以下同文。

        word1.image = game_.assets['kotoba1.gif']; // word1にあらかじめロードしておいた画像を適用します。
　       word2.image = game_.assets['kotoba2.gif'];  // word2に　以下同文。
　       word3.image = game_.assets['kotoba3.gif'];   // word3に　以下同文。
　       word4.image = game_.assets['kotoba4.gif']; // word4に　以下同文。

	word1.x =  wiw * 0.3; // word1の横位置を設定します。　左から幅の30%
        word1.y =  wih * 0.15; // word1の縦位置を設定します。　上から高さの15%
	word1.scaleX = scx;   // 幅
	word1.scaleY = scy; 　　// 高さ
	word2.x =  wiw * 0.3; // word2の横位置を設定します。
        word2.y =  wih * 0.3;  // word2の縦位置を設定します。
	word2.scaleX = scx;   // 幅
	word2.scaleY = scy; 　　// 高さ
	word3.x =  wiw * 0.3; // word3の横位置を設定します。
        word3.y =  wih * 0.45; // word3の縦位置を設定します。
	word3.scaleX = scx;   // 幅を1倍にする
	word3.scaleY = scy; 　　// 高さを1倍にする
	word4.x =  wiw * 0.3; // word4の横位置を設定します。
        word4.y =  wih * 0.6;  // word4の縦位置を設定します。
	word4.scaleX = scx;   // 幅
	word4.scaleY = scy; 　　// 高さ

        game_.rootScene.addChild(word1); // シーンに画像を表示させます。
        game_.rootScene.addChild(word2); // 同上
        game_.rootScene.addChild(word3); // 同上
        game_.rootScene.addChild(word4); // 同上

        game_.rootScene.backgroundColor  = '#7ecef4'; // 動作部分の背景色の設定(16進数)。


        // シーンに「タッチイベント」を追加します。

            word1.addEventListener(Event.TOUCH_START, function(e) {  // word1をタッチしたら
		word1.tl.scaleBy( 0.9, 3, enchant.Easing.ELASTIC_EASEINOUT);　　//90%の大きさになり
                word1.tl.scaleBy( 1 / 0.9, 3, enchant.Easing.ELASTIC_EASEINOUT);　//元に戻る
                game_.assets['kotoba1.mp3'].clone().play(); //言葉を発声する
            });     
            word2.addEventListener(Event.TOUCH_START, function(e) {  // word2をタッチしたら
		word2.tl.scaleBy( 0.9, 3, enchant.Easing.ELASTIC_EASEINOUT);
                word2.tl.scaleBy( 1 / 0.9, 3, enchant.Easing.ELASTIC_EASEINOUT);
		game_.assets['kotoba2.mp3'].clone().play(); //言葉を発声する
            });
            word3.addEventListener(Event.TOUCH_START, function(e) {  // word3をタッチしたら
		word3.tl.scaleBy( 0.9, 3, enchant.Easing.ELASTIC_EASEINOUT);
                word3.tl.scaleBy( 1 / 0.9, 3, enchant.Easing.ELASTIC_EASEINOUT);
		game_.assets['kotoba3.mp3'].clone().play(); //言葉を発声する
            });
            word4.addEventListener(Event.TOUCH_START, function(e) {  // word4をタッチしたら
		word4.tl.scaleBy( 0.9, 3, enchant.Easing.ELASTIC_EASEINOUT);
                word4.tl.scaleBy( 1 / 0.9, 3, enchant.Easing.ELASTIC_EASEINOUT);
		game_.assets['kotoba4.mp3'].clone().play(); //言葉を発声する
            });

    }
    game_.start(); // スタートさせます

    // このようにスラッシュ2つで書き始めた行は「コメント」扱いとなります。プログラム中のメモとして活用しましょう。
    /* また、このようにスラッシュと米印を使うと、
        複数行に渡ってコメントを書くことができます。 */
};
