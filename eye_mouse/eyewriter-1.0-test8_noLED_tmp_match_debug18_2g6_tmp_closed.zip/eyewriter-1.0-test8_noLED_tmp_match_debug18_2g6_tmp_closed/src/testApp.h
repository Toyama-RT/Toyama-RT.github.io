#ifndef _TEST_APP
#define _TEST_APP


#include "ofMain.h"
#include "testApp.h"
#include "trackingManager.h"
#include "calibrationManager.h"
#include "testingScene.h"
#include "typingScene.h"
#include "pongScene.h"
#include "eyePlotterTestApp.h"
#include "eyeOsc.h"
#include "mouseControl.h"//todo

#include "ofxQtVideoSaver.h"

enum{

	MODE_TRACKING,  MODE_CALIBRATING,   MODE_TEST,  MODE_DRAW,
    MODE_TYPING,    MODE_PONG,          MODE_OSC,   MODE_MOUSE

};


class testApp : public ofBaseApp {

	public:

		testApp();
		void setup();
		void update();
		void draw();

		void keyPressed  (int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void resized(int w, int h);

        bool bMouseSimulation;
        bool bMouseEyeInputSimulation;


        bool		bSetCursor;//TODO
        bool		bSetBangBangControl;//TODO



        bool        bReturnCalibration;
        int         nDelay;



        ofPoint eyeSmoothed0;
        ofPoint eyeSmoothed;
        ofPoint eyeSmoothed2;
        ofPoint eyeSmoothed3;
        ofPoint eyeSmoothedOld;
        ofPoint eyeSmoothed2Old;

        ofPoint corrected;

        ofSoundPlayer mySound;
        ofSoundPlayer mySound2;
        ofSoundPlayer mySound3;
        ofSoundPlayer mySound4;


        ofSoundPlayer clickSound;
        ofSoundPlayer clickSound2;


        ofSoundPlayer mySound_DblBlink_1;
        ofSoundPlayer mySound_DblBlink_2;
        ofSoundPlayer mySound_DblBlink_3;
        ofSoundPlayer mySound_DblBlink_4;

        ofSoundPlayer mySound_TriBlink_1;
        ofSoundPlayer mySound_TriBlink_2;
        ofSoundPlayer mySound_TriBlink_3;
        ofSoundPlayer mySound_TriBlink_4;


        ofSoundPlayer mySound0_1;
        ofSoundPlayer mySound0_2;
        ofSoundPlayer mySound0_3;
        ofSoundPlayer mySound1_1;
        ofSoundPlayer mySound1_2;
        ofSoundPlayer mySound1_3;
        ofSoundPlayer mySound2_1;
        ofSoundPlayer mySound2_2;
        ofSoundPlayer mySound2_3;
        ofSoundPlayer mySound3_1;
        ofSoundPlayer mySound3_2;



        float eyeSmoothed_len;
        float min_len;
        float max_len;
        float min_len2;
        float a_len;


		//eyeTracker			tracker; //todo

        int mode;

		//----- scenes

		trackingManager			TM;
		calibrationManager		CM;
        testingScene            testScene;
        eyePlotterTestApp       eyeApp;
        typingScene				typeScene;
        pongScene				ponger;
        eyeOsc                  oscScene;
        mouseControl            mouseScene;//todo

		//------ drawing
		void drawHelp();

        float buttonSensitivity;


        RECT recDisplay0;//TODO
        HWND hWnd0;   //TODO
        RECT recDisplay;//TODO
        HWND hWnd;   //TODO


        clock_t timer_0;
        double  ntime_0;


/*
        clock_t timer_n;

        int tdelay_start;
        int tdelay_stop;

        bool bdelay_start;
        bool bdelay_stop;
*/

        vector <float>          eyeSmoothed_val_x;
        vector <float>          eyeSmoothed_val_y;
        vector <float>          eyeSmoothed2_val_x;
        vector <float>          eyeSmoothed2_val_y;




        vector <float>          corrected_val_x;
        vector <float>          corrected_val_y;


        //int corrected_x;
        //int corrected_y;


        int Imove;

        string pathLeft;
        string pathTop;
        string pathBottom;
        string pathRight;


        bool bcalibration_threshold;
        float nbrightness;

        ofxQtVideoSaver qtsaver;
        bool bqtsaver;


        int imageID;
        string str0;


};

#endif
