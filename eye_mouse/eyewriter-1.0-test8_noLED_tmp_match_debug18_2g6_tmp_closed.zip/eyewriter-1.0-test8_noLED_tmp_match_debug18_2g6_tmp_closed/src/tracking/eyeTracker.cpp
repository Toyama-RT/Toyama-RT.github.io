#include "eyeTracker.h"


#include "FitEllipse.h"


//--------------------------------------------------------------
eyeTracker::eyeTracker(){

	bFoundOne	= false;
	//scalef		= 1;
	//xoffset		= 0;
	//yoffset		= 0;

}




//--------------------------------------------------------------
void eyeTracker::setup(int width, int height){

	w = width;//640
	h = height;//480

	colorImg.allocate(w, h);

	grayImgPreWarp.allocate(w, h);
	grayImgPreModification.allocate(w, h);
	grayImg.allocate(w, h);
	threshImg.allocate(w, h);
	edgeMask.allocate(w, h);
	edgeMaskInverted.allocate(w,h);


	grayImgPreWarp2.allocate(w, h);
	grayImgPreWarp3.allocate(w, h);
	grayImgPreWarp_B.allocate(w, h);
	grayImgPreWarp_D.allocate(w, h);
	grayImgPreWarp_O.allocate(w, h);

    grayROIImg.allocate(w,h);//TODO
    grayROIImg_.allocate(w,h);//TODO

    tmpMatched.allocate(w,h);//TODO
    tmpMatched_norect.allocate(w,h);//TODO
    tmpMatched_tmp.allocate(w,h);//TODO
    tmpMatched_B.allocate(w,h);//TODO


	grayBg0.allocate(w,h);//TODO
	grayBg.allocate(w,h);//TODO
	grayDiff.allocate(w,h);//TODO

	grayBg2.allocate(w,h);//TODO
	grayDiff2.allocate(w,h);//TODO


	laplaceImg.allocate(w,h);//TODO
	sobleImg.allocate(w,h);//TODO
	cannyImg.allocate(w,h);//TODO
	histImg.allocate(w,h);//TODO

    bLearnBakground = true;//TODO
    bSetTemplate = true;//TODO
    bSetTemplate2 = false;//TODO
    bSetTemplate3 = false;//TODO

    bSetAuto = false;//TODO//�e���v���[�g�摜�̐ݒ�̎�����
    nAutoStage=0;

    bSetAutoAll = false;//TODO//�N�����Ƀe���v���[�g�摜�A臒l�A�L�����u���[�V�������������A�g���ɂ����B
    nAutoAllStage=0;

    bSetAutoCalibration = false;//TODO
    nAutoStage2=0;


    bSetAutoTmpUpdate = false;//TODO
    nAutoStage3=0;


	eyeTrackedEllipse.imageWidth = w;
	eyeTrackedEllipse.imageHeight = h;

	threshold			= 60;
	currentEyePoint.set( 0 , 0 );

	// filtering:
	bUseGamma			= false;
	gamma				= 1.0f;

	bUseContrast		= false;
	contrast			= 0.2;
	brightness			= 0.0;


	bUseDilate			= false;
	nDilations			= 1;


	// for opencv hull
	storage	= cvCreateMemStorage(0);

	flipX = false;
	flipY = false;

	edgeMaskStartPos.set(w/2, h/2);
	edgeMaskInnerRadius = 250;
	edgeMaskOuterRadius = 350;
	edgeMaskPixels = new unsigned char [ (int)(w * h) ];


	// compactness test
	bUseCompactnessTest = false;
	maxCompactness = 0; // what would be a reasonable initial value for that?

	calculateEdgePixels();


    blink_time =0.5f; //TODO

//�܂΂����ŃN���b�N����@�r�M�i�[���[�h�̐ݒ蕔
//bbeginner_mode=true; �@�Ńr�M�i�[���[�h�P�@�V���O���N���b�N�̂݉\
//bbeginner_mode=true; bbeginner_mode2=true; ����true��beginnermode�Q�ɂȂ�_�u���N���b�N���\
//bbeginner_mode=true; bbeginner_mode2=false; ������alse�Œʏ탂�[�h�ɂȂ�S�ĉ\�@�@�\�������g���؂�Ȃ��@������
    bbeginner_mode =true;
    bbeginner_mode2=true;



    mode=MODE_CLICK;
    stage=STAGE_0;




    bSetEdgeFixer=false;


    bClick      =false; //TODO
    bDoubleClick=false;
    bRightClick =false;
    bDrag       =false;
    bDrop       =false;

    bFastBlink  =false;
    bDoubleBlink=false;

    bResizeWindow=false;
    bmodeResizeWindow=true;


    bBlinkUP  =false; //TODO
    bBlinkDOWN=false; //TODO

    bBlinkUP_corr  =false; //TODO
    bBlinkDOWN_corr=false; //TODO

    bStart=false; //TODO
    bEnd=false; //TODO
    bSetRest = false;

    bLeft=false;
    bRight=false;
    bUp=false;
    bDown=false;


    bNullTime=false;
    bNullTimeStart=false;
    bNullTimeEnd=false;

    ntime=0;
    nntime=0;
    nnntime=0;

    nDoubleBlink=0;


    bPleaseBlink=false;
    bReturnInfo=false;

    bContinuousClick_blink_up   = false; //TODO
    bContinuousClick_blink_down = false; //TODO

    bContinuousClick_blink_up_corr   = false; //TODO
    bContinuousClick_blink_down_corr = false; //TODO

    bset_current_loc=false;
    bfirst_current_loc=true;
    bOutOfLoc=false;



    bClickWav=false;
    bClickWav2=false;
    bClickWav3=false;
    bClickWav4=false;
    bWavPlay=false;
    bWavPlay2=false;
    bWavPlay3=false;
    bWavPlay4=false;

    bClickWav_DblBlink_1=false;
    bClickWav_DblBlink_2=false;
    bClickWav_DblBlink_3=false;
    bClickWav_DblBlink_4=false;
    bWavPlay_DblBlink_1 =false;
    bWavPlay_DblBlink_2 =false;
    bWavPlay_DblBlink_3 =false;
    bWavPlay_DblBlink_4 =false;

    bClickWav_TriBlink_1=false;
    bClickWav_TriBlink_2=false;
    bClickWav_TriBlink_3=false;
    bClickWav_TriBlink_4=false;
    bWavPlay_TriBlink_1 =false;
    bWavPlay_TriBlink_2 =false;
    bWavPlay_TriBlink_3 =false;
    bWavPlay_TriBlink_4 =false;


    bClickWav0_1=false;
    bClickWav0_2=false;
    bClickWav0_3=false;
    bClickWav1_1=false;
    bClickWav1_2=false;
    bClickWav1_3=false;
    //bClickWav1_4=false;
    //bClickWav1_5=false;
    bClickWav2_1=false;
    bClickWav2_2=false;
    bClickWav2_3=false;
    //bClickWav2_4=false;
    //bClickWav2_5=false;
    bClickWav3_1=false;
    bClickWav3_2=false;



    bWavPlay0_1 =false;
    bWavPlay0_2 =false;
    bWavPlay0_3 =false;
    bWavPlay1_1 =false;
    bWavPlay1_2 =false;
    bWavPlay1_3 =false;
    //bWavPlay1_4 =false;
    //bWavPlay1_5 =false;
    bWavPlay2_1 =false;
    bWavPlay2_2 =false;
    bWavPlay2_3 =false;
    //bWavPlay2_4 =false;
    //bWavPlay2_5 =false;
    bWavPlay3_1 =false;
    bWavPlay3_2 =false;



    bSetFrameRate=true;

//TODO
	for (int i = 0; i < 640; i++){

		tmp_val_x3.push_back(0);
		tmp_val_y3.push_back(0);

	}



	for (int i = 0; i < width/2; i++){

		corr_val.push_back( 1.0 );
		corr_D_val.push_back( 1.0 );
//		corr_diff_val.push_back( 0 );


		corr_val_closed.push_back( 1.0 );



		debug_val.push_back( 0 );//TODO
		debug_null_time.push_back( 0 );//TODO


		//blink_val.push_back( 0 );
		click_val_blink_up.push_back( 0 );
		click_val_blink_down.push_back( 0 );

		click_val_blink_up_corr.push_back( 0 );
		click_val_blink_down_corr.push_back( 0 );

		click_val_dbl_blink.push_back( 0 );

		diff_val_x.push_back(0);
		diff_val_y.push_back(0);

		left_val.push_back(0);
		right_val.push_back(0);
		up_val.push_back(0);
		down_val.push_back(0);
	}


	pixels      = new unsigned char [width * height];
	pixels0     = new unsigned char [width * height];
	pixels1     = new unsigned char [width * height];


	histogram_width = new int [width];
	histogram_height = new int [height];

    bSaveCalibOpen=false;
    bSetCalibOpen=false;


    //xml�t�@�C������A�e���v���[�g�摜�̓ǂݍ���:20140922
	ofxXmlSettings xml;
	xml.loadFile("settings/templateSettings.xml");
    nTemplate=xml.getValue("nTemplate", 0);

	for (int i = 0; i < nTemplate; i++) {

		xml.pushTag("templateFile",i);
		str_tmp_vec.push_back(xml.getValue("f", ""));
		xml.popTag();
		cout << "templateFile:" << str_tmp_vec[i] << endl;

	}

}


//--------------------------------------------------------------
void eyeTracker::flip(bool bHorizontal, bool bVertical){
	flipX = bHorizontal;
	flipY = bVertical;
}


//--------------------------------------------------------------
void eyeTracker::calculateEdgePixels(){
	for (int i = 0; i < w; i++){
		for (int j = 0; j < h; j++){
			float dx = i - edgeMaskStartPos.x;
			float dy = j - edgeMaskStartPos.y;
			float dist = sqrt(dx*dx + dy*dy);
			float pct = (dist - edgeMaskInnerRadius) / (edgeMaskOuterRadius - edgeMaskInnerRadius);
			if (pct < 0) pct = 0;
			if (pct > 1) pct = 1;
			edgeMaskPixels[(int)(j * w + i)] = pct * 255;
		}
	}
	edgeMask.setFromPixels(edgeMaskPixels, w,h);

	edgeMaskInverted = edgeMask;
	edgeMaskInverted.invert();
}



//--------------------------------------------------------------

vector <ofPoint> eyeTracker::getNormPoints(){
	return normPoints;
}

//--------------------------------------------------------------
ofPoint eyeTracker::getTempAverage(){
	return tempAverage;
}


//--------------------------------------------------------------
ofPoint eyeTracker::getEyePoint(){
	return currentEyePoint;
}

//--------------------------------------------------------------
ofPoint eyeTracker::getNormPoint(){
	return currentNormPoint;
}

//--------------------------------------------------------------
void eyeTracker::update(ofxCvGrayscaleImage & grayImgFromCam, float threshold, float minSize, float maxSize,  float minSquareness, int width, int height){


    //�t���[�����[�g�̕ύX�i8�L�[���������Ƃ��̏����j
    if (bSetFrameRate){
        ofSetFrameRate(30);//TODO
    }else{
        ofSetFrameRate(1);//TODO
    }


	//threshold?
	//threshold = thresh;

	//�J�����摜��荞�ݕ�

	grayImgPreWarp.setFromPixels(grayImgFromCam.getPixels(), grayImgFromCam.width, grayImgFromCam.height);		// TODO: there's maybe an unnecessary grayscale image (and copy) here...

  //��荞�݉摜�̏㉺���E���]�����@flipx,y �̃`�F�b�N�ɂ����s�����B
	if( flipX || flipY ){
		grayImgPreWarp.mirror(flipY, flipX);
	}

	grayImg = grayImgPreWarp;


//�@�R���g���X�g������

	grayImgPreModification = grayImg;
	grayImg.blur(5);

	if (bUseContrast == true){
		grayImg.applyBrightnessContrast(brightness,contrast);
	}
//�@�K���}�l������
	if (bUseGamma == true){
		grayImg.applyMinMaxGamma(gamma);
	}

	grayImg += edgeMask;
	threshImg = grayImg;

    grayImgPreWarp_B=grayImgPreWarp;
    grayImgPreWarp_D=grayImgPreWarp;
    grayImgPreWarp_O=grayImgPreWarp;



    if (tempRadius!=edgeMaskInnerRadius){
        btempRadius=true;
    }else{
        btempRadius=false;
    }

    //�e�펩�����̎���
    //�P��:sec
    float tSetAuto=0.2;
    float tBlink=15;
    float tInterval=1;
    float tInterval2=5;

    float tSetAutoAll_1=tSetAuto;
    float tSetAutoAll_2=tSetAuto*2;
    float tSetAutoAll_3=tSetAuto*3;
    float tSetAutoAll_4=tSetAuto*4;
    float tSetAutoAll_5=tSetAuto*5;
    float tSetAutoAll_6=tSetAuto*5+tBlink;
    float tSetAutoAll_7=tSetAutoAll_6+tInterval;
    float tSetAutoAll_8=tSetAutoAll_7+tInterval;
    float tSetAutoAll_9=tSetAutoAll_8+tInterval;

    //�J�n���ɁA�Ȃ���HH�ɕ��̒l���Ƃ�G���[�̗�O����
    if(clock()>5000){//�o�O�̉��(���񎞂ɂ́A����ȃT�C�Y������Ȃ��炵���B)�i���̍s���Ȃ��Ɠ��삵�Ȃ��B�N�����̃J���������Ɏ��Ԃ������邽�߂��H�j


//�@�N�����̏������������@�ݒ�́@eyetracker setup �ɂ���


        //�e���v���[�g�摜�̐ݒ�̎������ik�L�[���������Ƃ��̏����Ɠ����j
        if (bSetAuto){

            if(nAutoStage==0){
                timer_SetAuto=clock();
                nAutoStage++;
            }

            ntime_SetAuto=double (clock()-timer_SetAuto)/1000;

            if(tSetAuto<=ntime_SetAuto && nAutoStage==1){
                bSetTemplate3=true;
                nAutoStage++;
            }

           if(tSetAuto*2<=ntime_SetAuto && nAutoStage==2){

                keybd_event( 'P', 0, 0, 0 );
                keybd_event( 'P', 0, KEYEVENTF_KEYUP, 0);
                nAutoStage++;
            }


          if(tSetAuto*3<=ntime_SetAuto && nAutoStage==3){
                bSetTemplate2=true;
                nAutoStage++;
            }


          if(tSetAuto*4<=ntime_SetAuto && nAutoStage==4){
                keybd_event( 'P', 0, 0, 0 );
                keybd_event( 'P', 0, KEYEVENTF_KEYUP, 0);
                nAutoStage=0;
                bSetAuto=false;
            }

        }



        //�L�����u���[�V�����̎������il�L�[�����������̏����Ɠ����j
        if (bSetAutoCalibration){

            if(nAutoStage2==0){
                timer_SetAuto2=clock();
                nAutoStage2++;
            }

            ntime_SetAuto2=double (clock()-timer_SetAuto2)/1000;

            if(tInterval<=ntime_SetAuto2 && nAutoStage2==1){

                HWND hWnd = GetActiveWindow();
                ShowWindow( hWnd, SW_SHOWMAXIMIZED );

                keybd_event( OF_KEY_RETURN, 0, 0, 0 );
                keybd_event( OF_KEY_RETURN, 0, KEYEVENTF_KEYUP, 0);
                nAutoStage2++;
            }

           if(tInterval*2<=ntime_SetAuto2 && nAutoStage2==2){

                keybd_event( ' ', 0, 0, 0 );
                keybd_event( ' ', 0, KEYEVENTF_KEYUP, 0);
                nAutoStage2++;
            }


          if(tInterval*3<=ntime_SetAuto2 && nAutoStage2==3){
                keybd_event( ' ', 0, 0, 0 );
                keybd_event( ' ', 0, KEYEVENTF_KEYUP, 0);
                nAutoStage2=0;
                bSetAutoCalibration=false;
            }

        }




        //���݃}�b�`���Ă���摜���e���v���[�g�摜�Ƃ��Ď����X�V����(��U�X�V������AtInterval2=5�b�ԁA��~����)
        if (bSetAutoTmpUpdate){

            if(nAutoStage3==0){
                timer_SetAuto3=clock();
                nAutoStage3++;
            }

            ntime_SetAuto3=double (clock()-timer_SetAuto3)/1000;

            if(0<=ntime_SetAuto3 && nAutoStage3==1){
                bSetTemplate2=true;
                nAutoStage3++;
            }

           if(tSetAuto<=ntime_SetAuto3 && nAutoStage3==2){
                keybd_event( 'P', 0, 0, 0 );
                keybd_event( 'P', 0, KEYEVENTF_KEYUP, 0);
                nAutoStage3++;
            }


          if(tSetAuto+tInterval2<=ntime_SetAuto3 && nAutoStage3==3){
                nAutoStage3=0;
                bSetAutoTmpUpdate=false;
            }

        }

//�@�N�����̏������������͂����܂�



////////////////////////////////////////////////////////
//�@�e���v���[�g�}�b�`���O��p�����ዅ�ʒu�v���ƊJ��ᔻ�蕔��
////////////////////////////////////////////////////////


        //�\��templateSettings.xml�ɓo�^���Ă��鍕�ۂ̃e���v���[�g�摜����A�ł����֌W���̍����e���v���[�g�摜��I������itemplate_calib.bmp�Ƃ��ĕۑ�����j
        //�i1�L�[���������Ƃ��̏����j

        //���i�K�@�l�X�ȑ傫���̂ƌ`��̖͋[�e���v���[�g�̒�����A�J�����摜�̒��̊ዅ�ɍł��K�����镨��I��
        //�J�����̔z�u�A�����A�ዅ�̌l���Ȃǂ̉e������茸�炵����ŁA�J�����摜�̊ዅ�������e���v���[�g�Ƃ��Ď��o��
        if (bSetCalibOpen){

            src_img_O = grayImgPreWarp_O.getCvImage();//�C���[�W�摜


            //imageID=0;
            float val=0;
            tmpID=0;


            for (int i = 0; i < nTemplate; i++){



                //�t�@�C������ǂݍ��񂾃e���v���[�g�摜
                loadImg_O.loadImage(str_tmp_vec[i]);
                loadImg_O.setImageType(OF_IMAGE_GRAYSCALE);


                grayImg_O.allocate(loadImg_O.getWidth(),loadImg_O.getHeight());//TODO
                grayImg_O.setFromPixels(loadImg_O.getPixels(),loadImg_O.getWidth(),loadImg_O.getHeight());

                int TemplateWidth  = loadImg_O.getWidth();
                int TemplateHeight = loadImg_O.getHeight();



                ////////////////////////////////////////////////////////////////
                //�͋[�e���v���[�g�̃}�b�`���O���
                tmp_img_O = grayImg_O.getCvImage();


                int WW=width - TemplateWidth + 1;
                int HH=height - TemplateHeight + 1;

                // �T���摜�S�̂ɑ΂��āC�e���v���[�g�̃}�b�`���O�l�i�w�肵����@�Ɉˑ��j���v�Z
                dst_img_O = cvCreateImage (cvSize (WW, HH), IPL_DEPTH_32F, 1);

                cvMatchTemplate (src_img_O, tmp_img_O, dst_img_O, CV_TM_CCOEFF_NORMED);
                cvMinMaxLoc (dst_img_O, &min_val_O, &max_val_O, &min_loc_O, &max_loc_O, NULL);


                //�������̉��
                cvReleaseImage(&dst_img_O);



                //vec_corr.push_back( max_val);
                //vec_x.push_back( max_loc.x);
                //vec_y.push_back( max_loc.y);
                //�ł����֌W���̍����e���v���[�g�摜��T��
                if(val<max_val_O){
                    val=max_val_O;
                    tmpID=i;
                     //cout << "[" << i << "]" << str_tmp_vec[i] << ": " << max_val << ", (" << max_loc.x << ", " << max_loc.y << ")" <<" <" << endl;
                }else{

                    //cout << "[" << i << "]" << str_tmp_vec[i] << ": " << max_val <<  ", (" << max_loc.x << ", " << max_loc.y << ")" << endl;
                }

                //src_img_=cvCloneImage( src_img );
                //cvCopy(src_img, src_img_);





            }


            loadImg_O.loadImage(str_tmp_vec[tmpID]);
            loadImg_O.setImageType(OF_IMAGE_GRAYSCALE);

            grayROIImg2.allocate(loadImg_O.getWidth(),loadImg_O.getHeight());//TODO
            grayROIImg2.setFromPixels(loadImg_O.getPixels(),loadImg_O.getWidth(),loadImg_O.getHeight());

            //TODO
            //saveImg1.grabScreen(20+320, 20+240, loadImg_O.getWidth(),loadImg_O.getHeight());
            //saveImg1.saveImage("template01.png");

            tmp_img_save = grayROIImg2.getCvImage();
            cvSaveImage("data\\template_calib.bmp", tmp_img_save);
            cvSaveImage("data\\template_tmp.bmp", tmp_img_save);

            bSetCalibOpen=false;

            //bSaveCalibOpen=true;


        }

// �@���i�K�@�œK�͋[�e���v���[�g�Ƀ}�b�`�����摜���J�����摜����؂�o���ۑ�����

        int ROIX = edgeMaskStartPos.x-edgeMaskInnerRadius;//�؂蔲���ʒuX,Y
        int ROIY = edgeMaskStartPos.y-edgeMaskInnerRadius;
        int ROIWidth = 2*edgeMaskInnerRadius;//�؂蔲����,����
        int ROIHeight = 2*edgeMaskInnerRadius;

        //t�L�[���������A�G�b�W�t�B�N�T�[�̔��a(inner radius)��ύX�����Ƃ��ɁAtemplate_tmp.bmp��ۑ�����
        if (bSetTemplate || btempRadius){


            grayROIImg=grayImgPreWarp;
            grayROIImg.setROI(ROIX,ROIY,ROIWidth,ROIHeight);


            grayROIImg2.allocate(ROIWidth,ROIHeight);//TODO
            //grayROIImg2.resize(ROIWidth,ROIHeight);
            grayROIImg2.setFromPixels(grayROIImg.getRoiPixels(), ROIWidth,ROIHeight);


            tmp_img_tmp = grayROIImg2.getCvImage();
            cvSaveImage("data\\template_tmp.bmp", tmp_img_tmp);



            grayROIImg.resetROI();

            bSetTemplate=false;

        }

        //u�L�[���������Ƃ��̏����Ftemplate_calib.bmp��ǂݍ���ŁAtemplate_tmp.bmp�ɕۑ�����
        if (bSetTemplate3){

            //loadImg2.loadImage("template01.png");
            loadImg2.loadImage("template_calib.bmp");
            loadImg2.setImageType(OF_IMAGE_GRAYSCALE);

            grayROIImg2.allocate(loadImg2.getWidth(),loadImg2.getHeight());//TODO
            grayROIImg2.setFromPixels(loadImg2.getPixels(),loadImg2.getWidth(),loadImg2.getHeight());


            tmp_img_tmp = grayROIImg2.getCvImage();
            cvSaveImage("data\\template_tmp.bmp", tmp_img_tmp);


            bSetTemplate3=false;

        }

// ���i�K�����܂�


        //��e���v���[�g�摜�̏���
        //loadImg4.loadImage("template_closed.png");
        loadImg4.loadImage("template_closed.bmp");
        loadImg4.setImageType(OF_IMAGE_GRAYSCALE);

        grayROIImg2_C.allocate(loadImg4.getWidth(),loadImg4.getHeight());//TODO
        grayROIImg2_C.setFromPixels(loadImg4.getPixels(),loadImg4.getWidth(),loadImg4.getHeight());

        ROIWidth5  = loadImg4.getWidth();
        ROIHeight5 = loadImg4.getHeight();



        //�J��e���v���[�g�摜�̏���
        //loadImg3.loadImage("template.png");
        loadImg3.loadImage("template.bmp");
        loadImg3.setImageType(OF_IMAGE_GRAYSCALE);

        grayROIImg2_B.allocate(loadImg3.getWidth(),loadImg3.getHeight());//TODO
        grayROIImg2_B.setFromPixels(loadImg3.getPixels(),loadImg3.getWidth(),loadImg3.getHeight());

        ROIWidth3  = loadImg3.getWidth();
        ROIHeight3 = loadImg3.getHeight();

//�@�J��e���v���[�g�}�b�`���O�@��������

        //�J��e���v���[�g�摜�ɂ��J�����摜�}�b�`���O
        src_img_B = grayImgPreWarp_B.getCvImage();
        tmp_img_B = grayROIImg2_B.getCvImage();


        int WW3=width - ROIWidth3 + 1;
        int HH3=height - ROIHeight3 + 1;
        // �T���摜�S�̂ɑ΂��āC�e���v���[�g�̃}�b�`���O�l�i�w�肵����@�Ɉˑ��j���v�Z
        dst_size3 = cvSize (WW3, HH3);
      //dst_size = cvSize (src_img2->width - tmp_img2->width + 1, src_img2->height - tmp_img2->height + 1);
        dst_img_B = cvCreateImage (dst_size3, IPL_DEPTH_32F, 1);


        cvMatchTemplate (src_img_B, tmp_img_B, dst_img_B, CV_TM_CCOEFF_NORMED);
        cvMinMaxLoc (dst_img_B, &min_val3, &max_val3, &min_loc3, &max_loc3, NULL);

        // �e���v���[�g�ɑΉ�����ʒu�ɋ�`��`��
        cvRectangle (src_img_B, max_loc3,
                     cvPoint (max_loc3.x + tmp_img_B->width, max_loc3.y + tmp_img_B->height), CV_RGB (255, 0, 0), 3);

        //tmpMatched_B=src_img_B;


        cvReleaseImage(&dst_img_B);



        // max_val3:�e���v���[�g�}�b�`���O�̑��֌W���i�J��j�̍ő�l
        corr_val.erase(corr_val.begin());
        corr_val.push_back(max_val3);

        cout << "correlation coefficient:" << max_val3 << endl;



        //���֌W���̕��ϒl(�J��)
        //�J���臒l������������
        mean_corr=0;
        int nsizeo=corr_val.size();

        //for (int i=0; i<corr_val.size();i++){
        for (int i=nsizeo*1/2; i<nsizeo;i++){
            mean_corr+=corr_val[i];
        }
        //mean_corr/=corr_val.size();
        mean_corr/=nsizeo/2;


        //�J���臒l�̐ݒ�
        //threshold_corr_open=mean_corr-0.05;

        threshold_corr_open_O=mean_corr-0.05;
        threshold_corr_open_C=mean_corr-0.07;

//�J��e���v���[�g�}�b�`���O�@�����܂�


        //��e���v���[�g�}�b�`���O��������
        src_img_D = grayImgPreWarp_D.getCvImage();
        tmp_img_D = grayROIImg2_C.getCvImage();


        WW5=width - ROIWidth5 + 1;
        HH5=height - ROIHeight5 + 1;
        // �T���摜�S�̂ɑ΂��āC�e���v���[�g�̃}�b�`���O�l�i�w�肵����@�Ɉˑ��j���v�Z
        dst_size5 = cvSize (WW5, HH5);
        dst_img_D = cvCreateImage (dst_size5, IPL_DEPTH_32F, 1);


        cvMatchTemplate (src_img_D, tmp_img_D, dst_img_D, CV_TM_CCOEFF_NORMED);
        //cvMinMaxLoc (dst_img_D, &min_val5, &max_val5, &min_loc5, &max_loc5, NULL);

        // �e���v���[�g�ɑΉ�����ʒu�ɋ�`��`��
        //cvRectangle (src_img_B, max_loc5,
        //             cvPoint (max_loc5.x + tmp_img_D->width, max_loc5.y + tmp_img_D->height), CV_RGB (255, 0, 0), 3);

        //�ڂ��J�����摜�ƕ����摜�̗����̃}�b�`���O����
        //tmpMatched_B=src_img_B;



        ///////////////////////////////////////////////////////
        // 20140918:��e���v���[�g�̑��֌W���}�b�v�ɂ�����}�X�N����
        //��e���v���[�g�}�b�`���O�͔w�i�A���K�l�t���[���A���тȂǂɃ~�X�}�b�`���₷��
        //���̂��ߊJ���^���ł̑��֌W���̒l�̕ϓ���c�����ɂ����B�����Ń~�X�}�b�`�����炷�ړI�ŁA�J�᎞�ƕ᎞�ō��W�l�͑傫���ω����Ȃ��Ƃ̉����݂�
        //�}�X�N�������J�᎞�̍��W�l����ɕ�}�b�`���O�͈̔͂𐧌������B
        ///////////////////////////////////////////////////////
        if(bfirst_current_loc || bset_current_loc){//�N������'7'�L�[���������Ƃ��̏���
            current_loc=max_loc3;
            bfirst_current_loc=false;
            bset_current_loc=false;
        }


        // �}�X�N�̌��݈ʒu�ƍX�V�ʒu�̍���(����)
        float len=sqrt(pow((current_loc.x-max_loc3.x),2)+pow((current_loc.y-max_loc3.y),2));
        int max_len=50;
        if (len<max_len){
           current_loc=max_loc3;
           bOutOfLoc=false;
        }else{
           bOutOfLoc=true;

        }

        //cout << "len:" << len << endl;

        // cv::Mat�^�ɕϊ����āA�q�n�h�����߁A�}�X�N������0��������
        cv::Mat mat_img=cv::cvarrToMat(dst_img_D);
        //cout << mat_img.at<float>(max_Loc5.y,max_Loc5.x) << endl;;

        int vmask_w=150;
        int vmask_h=100;

        cv::Mat img_roi;

        if(current_loc.y-vmask_h>0){
            img_roi = mat_img(cv::Rect(0,0,WW5,current_loc.y-vmask_h));
            img_roi =cv::Scalar(0,0,0);
        }

        if(current_loc.x-vmask_w>0){
            img_roi = mat_img(cv::Rect(0,0,current_loc.x-vmask_w,HH5));
            img_roi =cv::Scalar(0,0,0);
        }

        if(current_loc.x+vmask_w<WW5){
            img_roi = mat_img(cv::Rect(current_loc.x+vmask_w,0,WW5-current_loc.x-vmask_w,HH5));
            img_roi =cv::Scalar(0,0,0);
        }

        if(current_loc.y+vmask_h<HH5){
            img_roi = mat_img(cv::Rect(0,current_loc.y+vmask_h,WW5,HH5-current_loc.y-vmask_h));
            img_roi =cv::Scalar(0,0,0);
        }

//�}�X�N���������܂�


        IplImage dst_img_D2=mat_img;


        cvMinMaxLoc (&dst_img_D2, &min_val5, &max_val5, &min_loc5, &max_loc5, NULL);

        // �e���v���[�g�ɑΉ�����ʒu�ɋ�`��`��
        cvRectangle (src_img_B, max_loc5,
                     cvPoint (max_loc5.x + tmp_img_D->width, max_loc5.y + tmp_img_D->height), CV_RGB (255, 0, 0), 3);

        //�ڂ��J�����摜�ƕ����摜�̗����̃}�b�`���O����
        tmpMatched_B=src_img_B;






        //���֌W���}�b�v�̕`��p�ɕϐ�dst_img_8u���`
        dst_img_8u = cvCreateImage(dst_size5, IPL_DEPTH_8U, 1);
        cvConvertImage(&dst_img_D2, dst_img_8u);




        //IplImage�^�Ń}�X�N�������s�����Ǝ��݂邪�A���܂��s���Ȃ������B


        corr_map_result.allocate(WW5,HH5);
        corr_map_result=dst_img_8u;



        cvReleaseImage(&dst_img_D);
        cvReleaseImage(&dst_img_8u);


        // max_val5:�e���v���[�g�}�b�`���O�̑��֌W���̍ő�l
        corr_D_val.erase(corr_D_val.begin());
        corr_D_val.push_back(max_val5);



        //���֌W���̕��ϒl
        mean_corr_D=0;
        int nsize=corr_D_val.size();

        //for (int i=0; i<nsize;i++){
        for (int i=nsize/2; i<nsize;i++){
            mean_corr_D+=corr_D_val[i];
        }
        mean_corr_D/=nsize/2;


        //�u����臒l�̐ݒ�
        threshold_corr_closed=mean_corr_D+0.05;

//��e���v���[�g�}�b�`���O�����܂�

//�@�J��A��e���v���[�g�}�b�`���O���W�Ƒ傫�����璆�S���W���Z�o

        Tmpx3	= max_loc3.x+ROIWidth3/2;
        Tmpy3	= max_loc3.y+ROIHeight3/2;

        Tmpx5	= max_loc5.x+ROIWidth5/2;
        Tmpy5	= max_loc5.y+ROIHeight5/2;


        //Tmpx2	= max_loc2.x+edgeMaskInnerRadius2+64;
        //Tmpy2	= Tmpy3;



        Tmpx0	= Tmpx3;
        Tmpy0	= Tmpy3;



        //y�L�[���������Ƃ��̏����F���݁A�J��e���v���[�g���}�b�`���Ă��镔���̉摜��template_tmp.bmp�Ƃ��ĕۑ�����
        if (bSetTemplate2){

            grayROIImg=grayImgPreWarp;
            grayROIImg.setROI(max_loc3.x,max_loc3.y,ROIWidth3,ROIHeight3);


            grayROIImg2.allocate(ROIWidth3,ROIHeight3);//TODO
            //grayROIImg2.resize(ROIWidth,ROIHeight);
            grayROIImg2.setFromPixels(grayROIImg.getRoiPixels(), ROIWidth3,ROIHeight3);


            tmp_img_tmp = grayROIImg2.getCvImage();
            cvSaveImage("data\\template_tmp.bmp", tmp_img_tmp);


            grayROIImg.resetROI();

            //�G�b�W�t�B�N�T�[�̈ʒu���ړ�����
            bSetEdgeFixer=true;


            bSetTemplate2=false;
        }



        tmp_val_x3.erase(tmp_val_x3.begin());
        tmp_val_x3.push_back(Tmpx3);

        tmp_val_y3.erase(tmp_val_y3.begin());
        tmp_val_y3.push_back(Tmpy3);


    }

   tempRadius=edgeMaskInnerRadius;




///////////////////////////////////////////////////////
//�q�X�g�O�����@�e���v���[�g�}�b�`���O�ȑO�ɃJ�����摜�̊K�����z��
//�ዅ���W�𐄒肷����@���������B
///////////////////////////////////////////////////////

	minVal = 255;
	maxVal = 0;
	maxVal1 = 0;
	maxVal2 = 0;

	maxVal_width = 0;
	minVal_width = 255*height;
	maxVal_height = 0;
	minVal_height = 255*width;


//	pixels = grayImgPreWarp.getPixels();
	pixels = grayImg.getPixels();

	pixels0 = grayBg2.getPixels();
	//pixels1 = grayImgPreModification.getPixels();
	pixels1 = grayImg.getPixels();






    //�q�X�g�O������Z�W���z�Ɋ֘A����l�̏�����
	for (int i = 0; i < 256; i++){
        histogramValues[i]=0;

	}

	for (int i = 0; i < width; i++){
        histogram_width[i]=0;

	}

	for (int i = 0; i < height; i++){
        histogram_height[i]=0;
	}


//-------------------------------------------


    //x���W�̔Z�W���z
	for (int i = 0; i < width; i++){
		for (int j = 0; j < height; j++){
			int pixVal = pixels[j*width + i];
			histogram_width[i]+=pixVal;
		}
	}

    //y���W�̔Z�W���z
    for (int j = 0; j < height; j++){
        for (int i = 0; i < width; i++){
			int pixVal = pixels[j*width + i];
			histogram_height[j]+=pixVal;
		}
	}


//-------------------------------------------

    //�s�N�Z���̍ŏ��l���W�̌��o
    int min_pixVal=255;
	for (int i = 0; i < width; i++){
		for (int j = 0; j < height; j++){
			int pixVal = pixels[j*width + i];

            if (pixVal <= min_pixVal) {
                min_pixVal = pixVal;
                minIdx_x=i;
                minIdx_y=j;
            }
		}
	}



    //x���W�̔Z�W���z�̍ő�l�E�ŏ��l
    //maxIdx_diffVal_w_pos=0;
    //maxIdx_diffVal_w_neg=0;
	for (int i = 0; i < width; i++){
		if (histogram_width[i] > maxVal_width){
			maxVal_width = histogram_width[i];
		}
		if (histogram_width[i] < minVal_width) {
			minVal_width = histogram_width[i];
		}

	}



    //y���W�̔Z�W���z�̍ő�l�E�ŏ��l�E�ŏ�y���W
    minIndex_height=0;

	for (int i = 0; i < height; i++){
		if (histogram_height[i] > maxVal_height){
			maxVal_height = histogram_height[i];

		}
		if (histogram_height[i] < minVal_height) {
			minVal_height = histogram_height[i];
			minIndex_height=i;
		}

	}

//�@�q�X�g�O�������������܂�


//-------------------------------------------
    //�܂΂����̔��蕔
//-------------------------------------------
    click_val_blink_up_corr.erase(click_val_blink_up_corr.begin());
    click_val_blink_down_corr.erase(click_val_blink_down_corr.begin());

//�J��ƕ�̔���ɂ́A�J��e���v���[�g�}�b�`���O�̑��֌W���l�ɑ΂��āA2��ނ�臒l��p����B
//�J��臒l�͕�臒l���������A����ɂ��n���`���O��h���@ohshima



    //�J�ᔻ�蕔

    if(max_val3>=threshold_corr_open_O && !bContinuousClick_blink_up_corr){

        //bBlinkUP_corr=true;
        bBlinkUP=true;
        click_val_blink_up_corr.push_back(1);
    }else{
        click_val_blink_up_corr.push_back(0);
    }


     if(max_val3>=threshold_corr_open_O){



        bContinuousClick_blink_up_corr = true;
    }else{
        bContinuousClick_blink_up_corr = false;
    }

    //�ᔻ�蕔

   if(max_val3<threshold_corr_open_C && !bContinuousClick_blink_down_corr){

        bBlinkDOWN=true;
        click_val_blink_down_corr.push_back(1);
    }else{
        click_val_blink_down_corr.push_back(0);
    }


   if(max_val3<threshold_corr_open_C){

        bContinuousClick_blink_down_corr = true;
    }else{
        bContinuousClick_blink_down_corr = false;
    }
//�܂΂������蕔
//�܂΂�����������@���ԁ@�P�ʁ@�b�@�Ⴉ��J��܂ł̎��Ԃɂ�蔻�肷��

/**/
    float tClickStart=0.5;//����ȉ��Ȃ玩�R�Ȃ܂΂���
    float tDoubleClickStart=1.5;//����ȏ�Ȃ獶�V���O���N���b�N
    float tRightClickStart=3.5;//����ȏ�Ȃ�_�u���N���b�N
    float tDrag=5.5;
    float tAdjustment=8.5;
    float tResizeWindow=12;
    float tRest=15;

    float tDblBlink=1.0;
    float tNtimesBlink=0.5;

    //�J�᎞�̗�O����
    if(bBlinkUP && !bBlinkDOWN){
        /*
        bBlinkDOWN=true;
        bStart=true;
        */

        bStart=false;
        bBlinkUP   = false;
        bBlinkDOWN = false;
        bClickWav=false;
        bClickWav2=false;
        bClickWav3=false;
        bClickWav4=false;




        if(bEnd){
            timer_n2=clock();
        }else{
            bNullTime=false;
        }

    }

    //�᎞�̏���
    if(bBlinkDOWN && !bStart){
        timer_n=clock();
        bStart=true;
        bNullTime=true;
        bNullTimeStart=true;
    }

   ///////////////////////////////////////////////
    if (!bSetAutoAll) {

       ///////////////////////////////////////////////
       if(mode==MODE_CLICK){


            if(!bbeginner_mode){
                //wav�t�@�C�����ǂ̃^�C�~���O�Ŗ炷���̏���
                if(!bBlinkUP && bBlinkDOWN && bStart){
                    nnntime=double (clock()-timer_n)/1000;


                    if(tRightClickStart<=nnntime && !bClickWav){
                        bClickWav=true;
                        bWavPlay=true;
                    }

                    if(tDrag<=nnntime && !bClickWav2){
                        bClickWav2=true;
                        bWavPlay2=true;
                    }


                }
            }



            //��̌�J�ᓮ��̔��蔻�f��
            if(bBlinkUP && bBlinkDOWN && bStart){
                ntime=double (clock()-timer_n)/1000;
                bStart=false;

                cout << "ntime:" << ntime << ", timer:" << timer_n << endl;

//�r�M�i�[���[�h�P�ł̓V���O���N���b�N�̂݁A�r�M�i�[���[�h�Q�ł̓_�u���N���b�N�����ʂ���

                if(bbeginner_mode){
//���R�Ȃ܂΂���
                      if(ntime<tClickStart){
                        str="Nothing!";
                    }


                    if (!bbeginner_mode2){
//�V���O���N���b�N
                         if(tClickStart<=ntime){
                            bClick=true;
                            str="Click!";
                        }

                    }else{

                        if(tClickStart<=ntime && ntime <tDoubleClickStart){
                            bClick=true;
                            str="Click!";
                        }
//�_�u���N���b�N
                        if(tDoubleClickStart<=ntime && ntime<tRightClickStart){
                            bDoubleClick=true;
                            str="Double Click!";
                        }
                    }

                }else{

//����ȍ~�͕W�����[�h
                     if(ntime<tClickStart){
                        n4time=double (clock()-timer_n4)/1000;

                        //cout << "n4time:" << n4time << endl;

                        if(n4time<tDblBlink){
                            timer_n5=clock();
                            bDoubleBlink=true;
                            nDoubleBlink++;

                        }else{
                            str="Nothing!";
                        }
                        timer_n4=clock();

                    }



                    if(tClickStart<=ntime && ntime <tDoubleClickStart){
                        bClick=true;
                        str="Click!";
                    }

                    if(tDoubleClickStart<=ntime && ntime<tRightClickStart){
                        bDoubleClick=true;
                        str="Double Click!";
                    }


                    if(tRightClickStart<=ntime && ntime<tDrag){
                        bRightClick=true;
                        str="Right Click!";
                    }



                   if(tDrag<=ntime ){
                        bDrag=true;
                        mode=MODE_DRAG;
                        str="Drag!";
                    }

//�X�ɑ����̋@�\�����݂���\��n
    /*
                   if(tDrag<=ntime && ntime<tAdjustment){
                        bDrag=true;
                        str="Drag!";
                    }


                    if(tAdjustment<=ntime && ntime<tResizeWindow){
                        mode=MODE_ADJUSTMENT;
                        stage=STAGE_0;
                        timer_n3=clock();
                        str="Adjustment mode";
                    }


                    //TODO
                    if(tResizeWindow<=ntime && ntime<tRest){
                        bResizeWindow=true;
                        if(bmodeResizeWindow==true){bmodeResizeWindow=false;}
                        else if(bmodeResizeWindow==false){bmodeResizeWindow=true;}
                        str="Resize Window";
                    }


                    if(tRest<=ntime){
                        bSetRest = true; //TODO
                        str="Rest!";
                    }
    */

                }

                cout << str << endl;


                bBlinkUP   = false;
                bBlinkDOWN = false;

                //TODO
                //bNullTime=false;
                bEnd=true;
                timer_n2=clock();


                bClickWav=false;
                bClickWav2=false;
                bClickWav3=false;
                bClickWav4=false;

            }

//������܂΂������蕔


            n5time=double (clock()-timer_n5)/1000;
            if(tNtimesBlink<n5time){

                //Double Blink
                if(nDoubleBlink==1){
                    mode=MODE_DOUBLE_BLINK;
                    timer_n3=clock();
                    str="Double Blink mode";
                }


                //Triple Blink
                if(nDoubleBlink==2){
                    mode=MODE_TRIPLE_BLINK;
                    timer_n3=clock();
                    str="Triple Blink mode";
                }


                //ntimes Blink
                if(2<nDoubleBlink){
                    ostringstream oss;
                    oss << nDoubleBlink+1 << " times Blink mode";
                    str=oss.str();
                }

//���̊J�ᓮ�씻�蕔�@�����܂�

                nDoubleBlink=0;

                if(mode!=MODE_CLICK){
                    bStart=false;
                    cout << str << endl;

                    bBlinkUP   = false;
                    bBlinkDOWN = false;

                    //TODO
                    //bNullTime=false;
                    bEnd=true;
                    timer_n2=clock();

                    bClickWav=false;
                    bClickWav2=false;
                    bClickWav3=false;
                    bClickWav4=false;
                }
            }



        }


        click_val_dbl_blink.erase(click_val_dbl_blink.begin());
        if(bDoubleBlink){
            click_val_dbl_blink.push_back(1);
            bDoubleBlink=false;
        }else{
            click_val_dbl_blink.push_back(0);
        }


      ///////////////////////////////////////////////
       if(mode==MODE_DRAG){

            //��̌�J�ᓮ��̔��ʔ��茋�ʂ��Ƃ̏���
            //��������DRAG���drop���瑽����܂΂����ȂǑ��l�ȋ@�\����肱�ނ��߂̌��ݗ\��n
            if(bBlinkUP && bBlinkDOWN && bStart){
                //ntime=double (clock()-timer_n)/1000;
                bStart=false;

                bDrop=true;
                str="Drop!";

                cout << str << endl;

                bBlinkUP   = false;
                bBlinkDOWN = false;

                mode=MODE_CLICK;

                //TODO
                //bNullTime=false;
                bEnd=true;
                timer_n2=clock();

            }

        }

      ///////////////////////////////////////////////
       if(mode==MODE_DOUBLE_BLINK){

            float tDblBlink_rest   =0;
            float tDblBlink_window =4.0;
            float tDblBlink_adj    =8.0;
            float tDblBlink_cancel =12.0;



                //wav�t�@�C�����ǂ̃^�C�~���O�Ŗ炷���̏���
                nnntime=double (clock()-timer_n3)/1000;


                if(tDblBlink_rest<=nnntime && !bClickWav_DblBlink_1){
                    bClickWav_DblBlink_1=true;
                    bWavPlay_DblBlink_1=true;
                }

                if(tDblBlink_window<=nnntime && !bClickWav_DblBlink_2){
                    bClickWav_DblBlink_2=true;
                    bWavPlay_DblBlink_2=true;
                }

                if(tDblBlink_adj<=nnntime && !bClickWav_DblBlink_3){
                    bClickWav_DblBlink_3=true;
                    bWavPlay_DblBlink_3=true;
                }

                if(tDblBlink_cancel<=nnntime && !bClickWav_DblBlink_4){
                    bClickWav_DblBlink_4=true;
                    bWavPlay_DblBlink_4=true;
                }




                if(bBlinkUP && bBlinkDOWN && bStart){
                    ntime=double (clock()-timer_n3)/1000;
                    bStart=false;

                    //cout << "ntime:" << ntime << ", timer:" << timer_n << endl;


                    if(tDblBlink_rest<=ntime && ntime <tDblBlink_window){
                        bSetRest = true; //TODO
                        str="Rest!";
                    }

                    if(tDblBlink_window<=ntime && ntime <tDblBlink_adj){
                        bResizeWindow=true;
                        if(bmodeResizeWindow==true){bmodeResizeWindow=false;}
                        else if(bmodeResizeWindow==false){bmodeResizeWindow=true;}
                        str="Resize Window";
                    }

                    if(tDblBlink_adj<=ntime && ntime <tDblBlink_cancel){
                        mode=MODE_ADJUSTMENT;
                        stage=STAGE_0;
                        timer_n3=clock();
                        str="Adjustment mode";
                    }


                    if(tDblBlink_cancel<=ntime){
                        str="Cancel";
                    }






                    //timer_n3=clock();
                    if(mode==MODE_DOUBLE_BLINK){
                        mode=MODE_CLICK;
                    }


                    bBlinkUP   = false;
                    bBlinkDOWN = false;

                    //TODO
                    //bNullTime=false;
                    bEnd=true;
                    timer_n2=clock();


                    bClickWav_DblBlink_1=false;
                    bClickWav_DblBlink_2=false;
                    bClickWav_DblBlink_3=false;
                    bClickWav_DblBlink_4=false;

                }

        }



      ///////////////////////////////////////////////
       if(mode==MODE_TRIPLE_BLINK){

            float tTripleBlink_1 =0;
            float tTripleBlink_2 =5.0;
            float tTripleBlink_3 =10.0;
            float tTripleBlink_4 =15.0;

            //wav�t�@�C�����ǂ̃^�C�~���O�Ŗ炷���̏���
            nnntime=double (clock()-timer_n3)/1000;


            if(tTripleBlink_1<=nnntime && !bClickWav_TriBlink_1){
                bClickWav_TriBlink_1=true;
                bWavPlay_TriBlink_1=true;
            }

            if(tTripleBlink_2<=nnntime && !bClickWav_TriBlink_2){
                bClickWav_TriBlink_2=true;
                bWavPlay_TriBlink_2=true;
            }

            if(tTripleBlink_3<=nnntime && !bClickWav_TriBlink_3){
                bClickWav_TriBlink_3=true;
                bWavPlay_TriBlink_3=true;
            }

           if(tTripleBlink_4<=nnntime && !bClickWav_TriBlink_4){
                bClickWav_TriBlink_4=true;
                bWavPlay_TriBlink_4=true;
            }


    /**/



            if(bBlinkUP && bBlinkDOWN && bStart){
                ntime=double (clock()-timer_n3)/1000;
                bStart=false;

                //cout << "ntime:" << ntime << ", timer:" << timer_n << endl;


    /*
                if(tTripleBlink_1<=ntime){
                    bDrag=true;
                    mode=MODE_DRAG;
                    str="Drag!";
                }

    */
                if(tTripleBlink_1<=ntime && ntime <tTripleBlink_2){
                    bDrag=true;
                    mode=MODE_DRAG;
                    str="Drag!";
                }

                if(tTripleBlink_2<=ntime && ntime <tTripleBlink_3){
                    keybd_event( OF_KEY_RETURN, 0, 0, 0 );
                    keybd_event( OF_KEY_RETURN, 0, KEYEVENTF_KEYUP, 0);
                    str="Enter!";

                }

                if(tTripleBlink_3<=ntime && ntime <tTripleBlink_4){
                    keybd_event( 'A', 0, 0, 0 );
                    keybd_event( 'A', 0, KEYEVENTF_KEYUP, 0);
                    str="Auto Setting!";
                }


                if(tTripleBlink_4<=ntime){
                    str="Cancel";
                }






                mode=MODE_CLICK;

                bBlinkUP   = false;
                bBlinkDOWN = false;

                //TODO
                //bNullTime=false;
                bEnd=true;
                timer_n2=clock();


                bClickWav_TriBlink_1=false;
                bClickWav_TriBlink_2=false;
                bClickWav_TriBlink_3=false;
                bClickWav_TriBlink_4=false;

            }


       }

        ///////////////////////////////////////////////
        if(mode==MODE_ADJUSTMENT){


            float tAdj_x=0;
            float tAdj_y=5.0;
            float tAdj_s=10.0;


            //wav�t�@�C�����ǂ̃^�C�~���O�Ŗ炷���̏���
            if(stage==STAGE_0){
                nnntime=double (clock()-timer_n3)/1000;


                if(tAdj_x<=nnntime && !bClickWav0_1){
                    bClickWav0_1=true;
                    bWavPlay0_1=true;
                }

                if(tAdj_y<=nnntime && !bClickWav0_2){
                    bClickWav0_2=true;
                    bWavPlay0_2=true;
                }

                if(tAdj_s<=nnntime && !bClickWav0_3){
                    bClickWav0_3=true;
                    bWavPlay0_3=true;
                }





                if(bBlinkUP && bBlinkDOWN && bStart){
                    ntime=double (clock()-timer_n3)/1000;
                    bStart=false;

                    //cout << "ntime:" << ntime << ", timer:" << timer_n << endl;


                    if(tAdj_x<=ntime && ntime <tAdj_y){
                        //bAdj_x=true;
                        stage=STAGE_1;
                        str="Adjustment x";
                    }

                    if(tAdj_y<=ntime && ntime <tAdj_s){
                        //bAdj_y=true;
                        stage=STAGE_2;
                        str="Adjustment y";
                    }

                    if(tAdj_s<=ntime){
                        stage=STAGE_3;
                        str="Adjustment scale";
                    }



                    timer_n3=clock();


                    bBlinkUP   = false;
                    bBlinkDOWN = false;

                    //TODO
                    //bNullTime=false;
                    bEnd=true;
                    timer_n2=clock();


                    bClickWav0_1=false;
                    bClickWav0_2=false;
                    bClickWav0_3=false;


                }
            }


            float tVal_x1=0;
            float tVal_x2=4.0;
            float tVal_x3=8.0;
            //float tVal_x4=12.0;
            //float tVal_x5=16.0;

            if(stage==STAGE_1){
                nnntime=double (clock()-timer_n3)/1000;


                if(tVal_x1<=nnntime && !bClickWav1_1){
                    bClickWav1_1=true;
                    bWavPlay1_1=true;
                }

                if(tVal_x2<=nnntime && !bClickWav1_2){
                    bClickWav1_2=true;
                    bWavPlay1_2=true;
                }

                if(tVal_x3<=nnntime && !bClickWav1_3){
                    bClickWav1_3=true;
                    bWavPlay1_3=true;
                }




                if(bBlinkUP && bBlinkDOWN && bStart){
                    ntime=double (clock()-timer_n3)/1000;
                    bStart=false;

                    //cout << "ntime:" << ntime << ", timer:" << timer_n << endl;

                    if(tVal_x1<=ntime && ntime <tVal_x2){
                        bVal_x1=true;
                        str="x:-100";
                    }

                    if(tVal_x2<=ntime && ntime <tVal_x3){
                        bVal_x2=true;
                        str="x:+100";
                    }

                    if(tVal_x3<=ntime ){
                        bVal_x3=true;
                        str="x:0";
                    }



                    mode=MODE_CLICK;
                    stage=STAGE_0;

                    bBlinkUP   = false;
                    bBlinkDOWN = false;

                    //TODO
                    //bNullTime=false;
                    bEnd=true;
                    timer_n2=clock();


                    bClickWav1_1=false;
                    bClickWav1_2=false;
                    bClickWav1_3=false;
                    //bClickWav1_4=false;
                    //bClickWav1_5=false;


                }
            }


           float tVal_y1=0;
            float tVal_y2=4.0;
            float tVal_y3=8.0;
            //float tVal_y4=12.0;
            //float tVal_y5=16.0;

            if(stage==STAGE_2){
                nnntime=double (clock()-timer_n3)/1000;


                if(tVal_y1<=nnntime && !bClickWav2_1){
                    bClickWav2_1=true;
                    bWavPlay2_1=true;
                }

                if(tVal_y2<=nnntime && !bClickWav2_2){
                    bClickWav2_2=true;
                    bWavPlay2_2=true;
                }

                if(tVal_y3<=nnntime && !bClickWav2_3){
                    bClickWav2_3=true;
                    bWavPlay2_3=true;
                }



                if(bBlinkUP && bBlinkDOWN && bStart){
                    ntime=double (clock()-timer_n3)/1000;
                    bStart=false;

                    //cout << "ntime:" << ntime << ", timer:" << timer_n << endl;

                   if(tVal_y1<=ntime && ntime <tVal_y2){
                        bVal_y1=true;
                        str="y:-100";
                    }

                    if(tVal_y2<=ntime && ntime <tVal_y3){
                        bVal_y2=true;
                        str="y:+100";
                    }

                    if(tVal_y3<=ntime ){
                        bVal_y3=true;
                        str="y:0";
                    }


                    mode=MODE_CLICK;
                    stage=STAGE_0;

                    bBlinkUP   = false;
                    bBlinkDOWN = false;

                    //TODO
                    //bNullTime=false;
                    bEnd=true;
                    timer_n2=clock();


                    bClickWav2_1=false;
                    bClickWav2_2=false;
                    bClickWav2_3=false;
                    //bClickWav2_4=false;
                    //bClickWav2_5=false;


                }
            }


            float tVal_s1=0;
            float tVal_s2=8.0;

            if(stage==STAGE_3){
                nnntime=double (clock()-timer_n3)/1000;


                if(tVal_s1<=nnntime && !bClickWav3_1){
                    bClickWav3_1=true;
                    bWavPlay3_1=true;
                }

                if(tVal_s2<=nnntime && !bClickWav3_2){
                    bClickWav3_2=true;
                    bWavPlay3_2=true;
                }



                if(bBlinkUP && bBlinkDOWN && bStart){
                    ntime=double (clock()-timer_n3)/1000;
                    bStart=false;

                    //cout << "ntime:" << ntime << ", timer:" << timer_n << endl;

                   if(tVal_s1<=ntime && ntime <tVal_s2){
                        bVal_s1=true;
                        str="y:+0.25";
                    }

                    if(tVal_s2<=ntime){
                        bVal_s2=true;
                        str="scale:1.0";
                    }


                    mode=MODE_CLICK;
                    stage=STAGE_0;

                    bBlinkUP   = false;
                    bBlinkDOWN = false;

                    //TODO
                    //bNullTime=false;
                    bEnd=true;
                    timer_n2=clock();


                    bClickWav3_1=false;
                    bClickWav3_2=false;

                }
            }



        }

//////////////////////////////////////////////
}

//���ݗ\��n�����܂�

//�J�ᒼ��͎�������܂炸�ዅ�^�����s����ŁA�J�[�\�����������Ȃ��@�����h��
    //�ڂ��J�����ۂ̕s�������Ԃ̐ݒ�
    //float nulltime=0.2;
    float nulltime=0.5;
    if(bEnd){
         nntime=double (clock()-timer_n2)/1000;
         if(nulltime<nntime){
            bEnd=false;
            bNullTime=false;
            //bNullTimeEnd=true;
         }
    }
/**/



        //cout << "FrameRate:" << ofGetFrameRate() << endl;


/*
    timer_n = clock();
    num0 = timer_n/1000-nsec;

    if (num0>1)
    {
        nsec++;
        cout << "threshold:" << nsec <<endl;

    }
    threshold = nsec;
*/


	threshImg.contrastStretch();
	threshImg.threshold(threshold, true);//��l������
    //threshImg.adaptiveThreshold(11,0,true,true);



	// the dilation of a 640 x 480 image is very slow, so let's just do a ROI near the thing we like:

	threshImg.setROI(currentEyePoint.x-50, currentEyePoint.y-50, 100,100);	// 200 pix ok?
	if (bUseDilate == true){
		for (int i = 0; i < nDilations; i++){
			threshImg.dilate();
		}
	}
	threshImg.resetROI();




    //TODO//�e���v���[�g�}�b�`���O�̌��ʂ�ϐ��Ɏ�荞��
    currentEyePoint.set(Tmpx0, Tmpy0); //
    currentNormPoint.x = Tmpx0;
    currentNormPoint.y = Tmpy0;

    currentNormPoint.x /= w;
    currentNormPoint.y /= h;

    bFoundOne = true;

    //cout << "currentEyePoint_x:" << currentEyePoint.x << ", currentEyePoint_y:" << currentEyePoint.y << endl;



}


//--------------------------------------------------------------
void eyeTracker::draw(float x, float y, float totalWidth, float totalHeight){


	ofPushMatrix();
		ofTranslate(x, y, 0);
		ofScale(totalWidth/(w*2), totalHeight/h, 1);

		ofSetColor(255, 255, 255);
		grayImg.draw(0,0);
		threshImg.draw(threshImg.width, 0);
		contourFinder.draw(threshImg.width, 0);

		if( currentEyePoint.x != 0 && currentEyePoint.y != 0 ){
			ofPushStyle();
				ofFill();
				ofSetColor(0, 0, 255);
				ofCircle( x + threshImg.width + currentNormPoint.x * threshImg.width, y + currentNormPoint.y * threshImg.height, 4);
			ofPopStyle();
		}

	ofPopMatrix();

	ofSetHexColor(0xffffff);
	ofDrawBitmapString("thresh is "+ofToString(threshold, 0), x, y + 10);




}


