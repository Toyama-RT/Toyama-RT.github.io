#pragma once


#include "ofMain.h"
#include "ofxOpenCv.h"
#include "ofxCvGrayscaleAdvanced.h"
#include "ofVectorMath.h"
#include <opencv2/opencv.hpp>
#include "ofxXmlSettings.h"


class eyeEllipse {

	public:

	int imageWidth;
	int imageHeight;

	float getWidth(){	return imageWidth; }
	float getHeight(){	return imageHeight; }
	float ellipseParam[5];	// ellipse parameters...

	void draw(float x, float y){
		draw(x,y, getWidth(), getHeight());
	}

	void draw(float x, float y, float w, float h){

		float axis_a = ellipseParam[0];
		float axis_b = ellipseParam[1];
		float cx 	 = ellipseParam[2];
		float cy 	 = ellipseParam[3];
		float theta	 = ellipseParam[4] * RAD_TO_DEG;
		float aspect = axis_b/axis_a;
		int resolution = 24;
		glPushMatrix();

			glTranslatef(x, y, 0);
			glScalef( (float)w/(float)getWidth(), (float)h/(float)getHeight(), 1);


			glTranslatef(cx,cy,0);
			glRotatef(theta, 0,0,1);

			glColor3f(1,0,1);
			glBegin(GL_LINE_LOOP);
			for (int i=0; i<resolution; i++){
				float t = TWO_PI * (float)i/(float)resolution;
				float ex = (axis_a * cos(t));
				float ey = (axis_b * sin(t));
				glVertex2f (ex,ey);
			}
			glEnd();


			glColor4f(1,0,1,0.1);
			glBegin(GL_POLYGON);
			for (int i=0; i<resolution; i++){
				float t = TWO_PI * (float)i/(float)resolution;
				float ex = (axis_a * cos(t));
				float ey = (axis_b * sin(t));
				glVertex2f (ex,ey);
			}
			glEnd();


			for (int i=0; i<resolution; i+=4){
				float t = TWO_PI * (float)i/(float)resolution;
				float ex = (axis_a * cos(t));
				float ey = (axis_b * sin(t));
				ofLine(0,0,ex,ey);
			}


		glPopMatrix();
	}
};



enum{

	MODE_CLICK,  MODE_DRAG, MODE_DOUBLE_BLINK, MODE_TRIPLE_BLINK, MODE_ADJUSTMENT

};

enum{

	STAGE_0,  STAGE_1, STAGE_2, STAGE_3

};



class eyeTracker{

	public:

		eyeTracker();
		void setup(int width, int height);
		void flip(bool bHorizontal, bool bVertical);
		//void update(ofxCvGrayscaleImage & grayImgFromCam, float threshold, float minSize, float maxSize,  float minSquareness=0.5); //TODO
		void update(ofxCvGrayscaleImage & grayImgFromCam, float threshold, float minSize, float maxSize,  float minSquareness, int width, int height); //TODO
		void draw(float x, float y, float w, float h);



		ofPoint getEyePoint();
		ofPoint getNormPoint();//TODO
        vector <ofPoint> getNormPoints();//TODO
		ofPoint getTempAverage();//TODO


		void setDownTime(int downWaitTimeMillis);
		void setUpTime(int upWaitTimeMillis);

		ofxCvGrayscaleImage			grayImgPreModification;

		/*float scalef;
		float xoffset;
		float yoffset;*/

		ofxCvGrayscaleAdvanced		grayImgPreWarp;



		ofxCvGrayscaleAdvanced		grayImg;
		ofxCvColorImage				colorImg;
		ofxCvGrayscaleAdvanced		threshImg;
		ofxCvContourFinder			contourFinder;

		ofxCvGrayscaleImage		    grayImgPreWarp2;
		ofxCvGrayscaleImage		    grayImgPreWarp3;
		ofxCvGrayscaleImage		    grayImgPreWarp_B;
		ofxCvGrayscaleImage		    grayImgPreWarp_D;
		ofxCvGrayscaleImage		    grayImgPreWarp_O;


        ofImage loadImg_O;
		ofxCvGrayscaleImage		grayImg_O;
		ofxCvGrayscaleImage		grayImg_O_;


		//ofxCvGrayscaleAdvanced		grayROIImg;//TODO
		//ofxCvGrayscaleAdvanced		grayROIImg2;//TODO

		ofxCvGrayscaleImage		grayROIImg;//TODO
		ofxCvGrayscaleImage		grayROIImg2;

		ofxCvGrayscaleImage		grayROIImg_;//TODO
		ofxCvGrayscaleImage		grayROIImg2_;


		ofxCvGrayscaleImage		    grayROIImg_tmp;//TODO
		ofxCvGrayscaleImage 		grayROIImg2_tmp;//TODO

		ofxCvGrayscaleImage		    grayROIImg_B;//TODO
		ofxCvGrayscaleImage 		grayROIImg2_B;//TODO

		ofxCvGrayscaleImage 		grayROIImg2_C;//TODO


		ofxCvGrayscaleImage		    corr_map_result;

		ofxCvGrayscaleImage		    tmpMatched;//TODO
		ofxCvGrayscaleImage		    tmpMatched_norect;//TODO
		ofxCvGrayscaleImage		    tmpMatched_tmp;//TODO
		ofxCvGrayscaleImage		    tmpMatched_B;//TODO

        //TODO

        ofxCvGrayscaleImage    laplaceImg;
        ofxCvGrayscaleImage    sobleImg;
        ofxCvGrayscaleImage    cannyImg;
        ofxCvGrayscaleImage    histImg;


 		ofxCvContourFinder	   contourFinder0;
        ofxCvGrayscaleAdvanced grayBg0; //�L���v�`���[�����w�i�摜
        ofxCvGrayscaleAdvanced grayBg; //�L���v�`���[�����w�i�摜
        ofxCvGrayscaleAdvanced grayDiff; //���݂̉摜�Ɣw�i�Ƃ̍���

        //TODO
 		ofxCvContourFinder	   contourFinder2;
        ofxCvGrayscaleAdvanced grayBg2; //�L���v�`���[�����w�i�摜
        ofxCvGrayscaleAdvanced grayDiff2; //���݂̉摜�Ɣw�i�Ƃ̍���


        bool bLearnBakground; //�w�i�摜��o�^�������ۂ�
        bool bSetTemplate;
        bool bSetTemplate2;
        bool bSetTemplate3;

        bool bSetAuto;
        int nAutoStage;

        bool bSetAutoAll;
        int nAutoAllStage;

        bool bSetAutoCalibration;
        int nAutoStage2;

        bool bSetAutoTmpUpdate;
        int nAutoStage3;


        float tempRadius;//TODO
        bool  btempRadius;//TODO

        float tempRadius2;//TODO
        bool  btempRadius2;//TODO

        float tempRadius3;//TODO
        bool  btempRadius3;//TODO

        int adj_x;
        int adj_y;
        float adj_scale;

        int target_x;
        int target_y;

//        int min_zone;
//        int max_zone;

//        int nmove;
//        float target_smoothing;



        int dead_zone;
        float min_smoothing;




        bool bbeginner_mode;
        bool bbeginner_mode2;


        int mode;
        int stage;



		void						calculateEdgePixels();
		ofPoint						edgeMaskStartPos;
		float						edgeMaskInnerRadius;			// < innerRadius = white
		float						edgeMaskOuterRadius;			// > inner radius and < outer radius = fade to black
		unsigned char				* edgeMaskPixels;				// > outer radius = black.....
		ofxCvGrayscaleImage			edgeMask;
		ofxCvGrayscaleImage			edgeMaskInverted;				// for display, easier to see what's going on.

		bool						bFoundOne;


		CvMemStorage *				storage;

		eyeEllipse					eyeTrackedEllipse;

		bool						bUseCompactnessTest;
		float						maxCompactness;



        bool                        bSetEdgeFixer;



/*
		void						calculateEdgePixels2();
		ofPoint						edgeMaskStartPos2; //TODO
		float						edgeMaskInnerRadius2; //TODO
		float						edgeMaskOuterRadius2; //TODO
		unsigned char				* edgeMaskPixels2;	 //TODO
		ofxCvGrayscaleImage			edgeMask2; //TODO
		ofxCvGrayscaleImage			edgeMaskInverted2; //TODO


		void						calculateEdgePixels3();
		ofPoint						edgeMaskStartPos3; //TODO
		float						edgeMaskInnerRadius3; //TODO
		float						edgeMaskOuterRadius3; //TODO
		unsigned char				* edgeMaskPixels3;	 //TODO
		ofxCvGrayscaleImage			edgeMask3; //TODO
		ofxCvGrayscaleImage			edgeMaskInverted3; //TODO
*/


		// filtering / options:
		bool		bUseGamma;
		float		gamma;

		bool		bUseContrast;
		float		contrast;
		float		brightness;

		bool		bUseDilate;
		int			nDilations;

		bool		flipX, flipY;

		float		w, h;
		float		threshold;




		ofPoint currentEyePoint;
		ofPoint currentNormPoint; //TODO
        vector <ofPoint> normPoints; //TODO
		ofPoint tempAverage; //TODO


        float blink_time;//TODO
        bool bCloseEye; //TODO
        bool bToggleEye;//TODO



        bool bVal_x1;
        bool bVal_x2;
        bool bVal_x3;

        bool bVal_y1;
        bool bVal_y2;
        bool bVal_y3;

        bool bVal_s1;
        bool bVal_s2;



        bool        bClick;//TODO
        bool		bDoubleClick; //TODO
        bool        bRightClick;
        bool        bDrag;
        bool        bDrop;

        bool        bFastBlink;
        bool        bDoubleBlink;

        bool bResizeWindow;
        bool bmodeResizeWindow;//false:min, true:max



        bool bBlinkUP;
        bool bBlinkDOWN;

        bool bBlinkUP_corr;
        bool bBlinkDOWN_corr;

        bool bSetRest;

        bool bNullTime;
        bool bNullTimeStart;
        bool bNullTimeEnd;

        bool bContinuousClick_blink_up;//TODO
        bool bContinuousClick_blink_down;//TODO


        bool bContinuousClick_blink_up_corr;//TODO
        bool bContinuousClick_blink_down_corr;//TODO


        bool bClickWav;
        bool bClickWav2;
        bool bClickWav3;
        bool bClickWav4;

        bool bWavPlay;
        bool bWavPlay2;
        bool bWavPlay3;
        bool bWavPlay4;


        bool bClickWav_DblBlink_1;
        bool bClickWav_DblBlink_2;
        bool bClickWav_DblBlink_3;
        bool bClickWav_DblBlink_4;
        bool bWavPlay_DblBlink_1;
        bool bWavPlay_DblBlink_2;
        bool bWavPlay_DblBlink_3;
        bool bWavPlay_DblBlink_4;

        bool bClickWav_TriBlink_1;
        bool bClickWav_TriBlink_2;
        bool bClickWav_TriBlink_3;
        bool bClickWav_TriBlink_4;
        bool bWavPlay_TriBlink_1;
        bool bWavPlay_TriBlink_2;
        bool bWavPlay_TriBlink_3;
        bool bWavPlay_TriBlink_4;


        bool bClickWav0_1;
        bool bClickWav0_2;
        bool bClickWav0_3;
        bool bClickWav1_1;
        bool bClickWav1_2;
        bool bClickWav1_3;
        //bool bClickWav1_4;
        //bool bClickWav1_5;
        bool bClickWav2_1;
        bool bClickWav2_2;
        bool bClickWav2_3;
        //bool bClickWav2_4;
        //bool bClickWav2_5;
        bool bClickWav3_1;
        bool bClickWav3_2;




        bool bWavPlay0_1;
        bool bWavPlay0_2;
        bool bWavPlay0_3;
        bool bWavPlay1_1;
        bool bWavPlay1_2;
        bool bWavPlay1_3;
        //bool bWavPlay1_4;
        //bool bWavPlay1_5;
        bool bWavPlay2_1;
        bool bWavPlay2_2;
        bool bWavPlay2_3;
        //bool bWavPlay2_4;
        //bool bWavPlay2_5;
        bool bWavPlay3_1;
        bool bWavPlay3_2;




        bool    bLeft;
        bool    bRight;
        bool    bUp;
        bool    bDown;

        bool    bContinuous;
        bool    bContinuous2;


        IplImage*               src_img;
        IplImage*               tmp_img;
        IplImage*               dst_img;

        IplImage*               src_img_O;
        IplImage*               tmp_img_O;
        IplImage*               dst_img_O;

        IplImage*               tmp_img_save;
        IplImage*               tmp_img_tmp;


        IplImage*               src_img2;
        IplImage*               tmp_img2;
        IplImage*               dst_img2;


        IplImage*               src_img2_tmp;
        IplImage*               tmp_img2_tmp;
        IplImage*               dst_img2_tmp;

        IplImage*               src_img_B;
        IplImage*               tmp_img_B;
        IplImage*               dst_img_B;

        IplImage*               src_img_C;
        IplImage*               tmp_img_C;
        IplImage*               dst_img_C;

        IplImage*               src_img_D;
        IplImage*               tmp_img_D;
        IplImage*               dst_img_D;


        IplImage*               dst_img_8u;


        ofImage loadImg1;
        ofImage loadImg2;
        ofImage loadImg3;

        ofImage loadImg4;


        ofImage saveImg1;
        ofImage saveImg2;
        ofImage saveImg3;



        double min_val, max_val;
        CvPoint min_loc, max_loc;
        CvSize dst_size;

        double min_val2, max_val2;
        CvPoint min_loc2, max_loc2;
        CvSize dst_size2;

        double min_val3, max_val3;
        CvPoint min_loc3, max_loc3;
        CvSize dst_size3;

        double min_val_O, max_val_O;
        CvPoint min_loc_O, max_loc_O;


        CvPoint current_loc;
        bool bfirst_current_loc;
        bool bset_current_loc;
        bool bOutOfLoc;


        int WW5;
        int HH5;




        double min_val4, max_val4;


        double min_val5, max_val5;
        CvPoint min_loc5, max_loc5;
        CvSize dst_size5;


//        double max_diff_val;


        int ROIWidth3;
        int ROIHeight3;

        int ROIWidth5;
        int ROIHeight5;


        CvPoint2D32f pos_Center;//TODO
        IplImage*               dst_img3;


        IplImage*               src_img2_copy;
        IplImage*               dst_img3_copy;



        float Tmpx;
        float Tmpy;

        float Tmpx2;
        float Tmpy2;

        float Tmpx3;
        float Tmpy3;

        float Tmpx5;
        float Tmpy5;


        float Tmpx0;
        float Tmpy0;



        vector <int>            tmp_val_x;
        vector <int>            tmp_val_y;

        vector <int>            tmp_val_x2;
        vector <int>            tmp_val_y2;

        vector <int>            tmp_val_x3;
        vector <int>            tmp_val_y3;



        IplImage*               hist_img;
        CvHistogram*            hist;



        vector <float>          corr_val;
        float                   mean_corr;


        vector <float>          corr_D_val;
        float                   mean_corr_D;

        float                   threshold_corr_closed;

        float                   threshold_corr_open;

        float                   threshold_corr_open_O;
        float                   threshold_corr_open_C;





//        vector <float>          corr_diff_val;
//        float                   mean_diff_corr;



        vector <float>          corr_val_closed;
        float                   mean_corr_closed;

        vector <float>          blink_val;
        vector <int>            click_val_blink_up;
        vector <int>            click_val_blink_down;

        vector <int>            click_val_blink_up_corr;
        vector <int>            click_val_blink_down_corr;

        vector <int>            click_val_dbl_blink;


        vector <int>            debug_val;//TODO
        vector <int>            debug_null_time;//TODO


        vector <float>          diff_val_x;
        vector <float>          diff_val_y;

        vector <int>            left_val;
        vector <int>            right_val;
        vector <int>            up_val;
        vector <int>            down_val;

        clock_t timer_n;
        clock_t timer_n2;
        clock_t timer_n3;
        clock_t timer_n4;
        clock_t timer_n5;

        clock_t timer_SetAuto;
        clock_t timer_SetAuto2;
        clock_t timer_SetAuto3;
        clock_t timer_SetAutoAll;

        bool bStart;
        bool bEnd;

        double ntime;
        double nntime;
        double nnntime;
        double n4time;
        double n5time;

        double ntime_SetAuto;
        double ntime_SetAuto2;
        double ntime_SetAuto3;
        double ntime_SetAutoAll;

        int nDoubleBlink;//todo

        string str;
        string str2;

        bool bPleaseBlink;
        bool bReturnInfo;


        unsigned char * pixels;
        unsigned char * pixels0;
        unsigned char * pixels1;
        int * pixels_diff;
        unsigned char * pixels_tmp; //TODO



        //int * diffVal_w_pos;
        //int * diffVal_w_neg;
        //int * diffVal_h_pos;
        //int * diffVal_h_neg;


        //float max_diffVal_w_pos;
        //float max_diffVal_w_neg;
        //float max_diffVal_h_pos;
        //float max_diffVal_h_neg;

        float maxIdx_diffVal_w_pos;
        float maxIdx_diffVal_w_neg;
        float maxIdx_diffVal_h_pos;
        float maxIdx_diffVal_h_neg;

        int centroid_x_pos;
        int centroid_x_neg;
        int centroid_y_pos;
        int centroid_y_neg;



		int histogramValues [256];
		int * histogram_width;	//TODO
		int * histogram_height;		//TODO


//		int * pixVal_width;	//TODO
//		int * pixVal_height;//TODO

//		int * min_pixVal_width;	//TODO
//		int * min_pixVal_height;//TODO


		//second image
//		unsigned char * resultingPixels;
//		ofTexture	texture;
//		int histogramValues1 [256];

//        float blinkUP_threshold;//todo
//        float blinkDOWN_threshold;//todo

//        float blinkUP_threshold_corr;//todo
//        float blinkDOWN_threshold_corr;//todo


        float Up_threshold;
        float Down_threshold;
        float Left_threshold;
        float Right_threshold;



        float maxVal_width;
        float minVal_width;
        float maxVal_height;
        float minVal_height;

        float minIndex_height;

		float minVal;
		float maxVal;
		int maxVal1;
		int maxVal2;


//        int centroid_x;
//        int centroid_y;


//        vector <int>    centroid_val_x;
//        vector <int>    centroid_val_y;


        int minIdx_x;
        int minIdx_y;


        float corr_max;
        float corr_min;



        bool bTemplateUpdate;

        float update_corr_closed_threshold;
        float corr_diff_threshold;


		//stuff for histogram equilization
		//unsigned int * numOccurances;
		//unsigned int * cdf;

		//ofTexture	texture1;
		//unsigned char * cdfPixels;
		//int eqHistogramVals [256];


        bool bSetFrameRate;
        bool bCalibrationAutoReturn;



        int nTemplate;
        vector <string> str_tmp_vec;
        bool bSetCalibOpen;
        int tmpID;
        bool bSaveCalibOpen;
};

