#include "trackingManager.h"
#include "buttonTrigger.h"

//#include <time.h>

//�g���b�L���O�}�l�[�W���Ƃ͋N����ŏ��ɕ\��������ʂŁA�����Ŋe��ݒ��J�����摜�ȂǊm�F����
trackingManager::trackingManager(){

}

trackingManager::~trackingManager(){

}

void trackingManager::setup(){



	IM.setup();

	setupGui();

	//--- set up tracking
	tracker.setup(IM.width, IM.height);
	minBlob		= 10*10;
	maxBlob		= 100*100;
	threshold	= 21;

	bFoundEye = false;
	eyePoint.set(0,0,0);

	font.loadFont("fonts/verdana.ttf", 36);
    //font.loadFont("fonts/HelveticaNeueMed.ttf", 72);
	font2.loadFont("fonts/verdana.ttf", 14);
	font3.loadFont("fonts/meiryob.ttc", 90);


    falseImg01.loadImage("images/false_01up_left.jpg");
    falseImg02.loadImage("images/false_02up.jpg");
    falseImg03.loadImage("images/false_03up_right.jpg");
    falseImg04.loadImage("images/false_04left.jpg");
    falseImg05.loadImage("images/false_05rest.jpg");
    falseImg06.loadImage("images/false_06right.jpg");
    falseImg07.loadImage("images/false_07down_left.jpg");
    falseImg08.loadImage("images/false_08down.jpg");
    falseImg09.loadImage("images/false_09down_right.jpg");

    trueImg01.loadImage("images/true_01up_left.jpg");
    trueImg02.loadImage("images/true_02up.jpg");
    trueImg03.loadImage("images/true_03up_right.jpg");
    trueImg04.loadImage("images/true_04left.jpg");
    trueImg05.loadImage("images/true_05rest.jpg");
    trueImg06.loadImage("images/true_06right.jpg");
    trueImg07.loadImage("images/true_07down_left.jpg");
    trueImg08.loadImage("images/true_08down.jpg");
    trueImg09.loadImage("images/true_09down_right.jpg");


    blinkInfo.loadImage("images/blinkInfo.png");
    returnInfo.loadImage("images/returnInfo.png");


}

void trackingManager::update(){
	//--- update video/camera input
	IM.update();

	//--- eye tracking (on new frames)
	if (IM.bIsFrameNew){
		trackEyes(IM.width, IM.height);
	}

	//--- gui
	panel.update();
	updateGui();
}



ofPoint	trackingManager::getEyePoint(){
	return eyePoint;
}

bool trackingManager::bGotAnEyeThisFrame(){
	return bFoundEye;
}

//--------------------------------------------------------------
void trackingManager::trackEyes(int width, int height){
	tracker.update(IM.grayImage, threshold, minBlob, maxBlob, 0.5f, width, height);
//	tracker.update(IM.grayImage, threshold, minBlob, maxBlob, 0.9f);

	bFoundEye	= tracker.bFoundOne;
	eyePoint	= tracker.getEyePoint();
}


void trackingManager::setupGui(){
//�����p�l���̐ݒ�
	panel.setup("cv panel", 680, 20, 300, 950);//�p�l���̔z�u�E�T�C�Y�̐ݒ�
	panel.addPanel("edge fixer", 1, false);	//TODO�F edge fixer��1�Ԗڂɔz�u
	panel.addPanel("image adjustment", 1, false);//TODO
	panel.addPanel("blob detection", 1, false);
    panel.addPanel("button settings", 1, false);

	if (IM.mode == INPUT_VIDEO){
		panel.addPanel("video file settings", 1, false);
	} else {
		panel.addPanel("live video settings", 1, false);
	}

	//---- img adjust
	panel.setWhichPanel("image adjustment");
	panel.setWhichColumn(0);
	panel.addToggle("flip horizontal ", "B_RIGHT_FLIP_X", false);
	panel.addToggle("flip vertical ", "B_RIGHT_FLIP_Y", false);
	panel.addToggle("use contrast / bri", "B_USE_CONTRAST", true);
	panel.addSlider("contrast ", "CONTRAST", 0.28f, 0.0, 1.0f, false);
	panel.addSlider("brightness ", "BRIGHTNESS", -0.02f, -1.0, 3.0f, false);
	panel.addToggle("use gamma ", "B_USE_GAMMA", true);
	panel.addSlider("gamma ", "GAMMA", 0.57f, 0.01, 3.0f, false);
	panel.addSlider("threshold ", "THRESHOLD_GAZE", threshold, 0, 255, true);

    //---- blog detect
	panel.setWhichPanel("blob detection");
	panel.addToggle("use dilate", "B_USE_DILATE", true);
	panel.addSlider("dilate num ", "N_DILATIONS", 0, 0, 10, true);
    panel.addSlider("min blob","MIN_BLOB",10*10,0,5000,true);
    panel.addSlider("max blob","MAX_BLOB",100*100,0,50500,true);
    /*
 	panel.addSlider("left threshold ",  "LEFT_THRESHOLD",  -20, -100, 100, true);//TODO
	panel.addSlider("right threshold ", "RIGHT_THRESHOLD",  20, -100, 100, true);//TODO
 	panel.addSlider("up threshold ",    "UP_THRESHOLD",     20, -100, 100, true);//TODO
	panel.addSlider("down threshold ",  "DOWN_THRESHOLD",  -20, -100, 100, true);//TODO
    */


	//---- tracker edges
	panel.setWhichPanel("edge fixer");
	panel.setWhichColumn(0);
	panel.addSlider("x position ", "EDGE_MASK_X", 320, 0, 640, true);
	panel.addSlider("y position ", "EDGE_MASK_Y", 240, 0, 480, true);
	panel.addSlider("inner radius ", "EDGE_MASK_INNER_RADIUS", 250, 0, 500, true);
	panel.addSlider("outer radius ", "EDGE_MASK_OUTER_RADIUS", 350, 0, 600, true);
	//panel.addSlider("blink up threshold ", "BLINK_UP_THRESHOLD", 10, -100, 100, true);//TODO
	//panel.addSlider("blink down threshold ", "BLINK_DOWN_THRESHOLD", -10, -100, 100, true);//TODO
	panel.addSlider("x adjustment ", "X_ADJUSTMENT", 0, -500, 500, true);
	panel.addSlider("y adjustment ", "Y_ADJUSTMENT", 0, -500, 500, true);
	panel.addSlider("scale adjustment ", "SCALE_ADJUSTMENT", 1.0f, 1.0f, 3.0f, false);
	panel.addSlider("x target ", "X_TARGET", 0, -1000, 1000, true);
	panel.addSlider("y target ", "Y_TARGET", 0, -1000, 1000, true);
	//panel.addSlider("min zone ", "MIN_ZONE", 100, 10, 150, true);
	//panel.addSlider("max zone ", "MAX_ZONE", 250, 160, 500, true);
	//panel.addSlider("velocity ", "VELOCITY", 3, 1, 30, true);
	//panel.addSlider("target smoothing ", "TARGET_SMOOTHING", 0.5, 0, 1, false);

	//panel.addSlider("blink up threshold(corr) ", "BLINK_UP_THRESHOLD_CORR", 0.8, 0, 1, false);//TODO
	//panel.addSlider("blink down threshold(corr) ", "BLINK_DOWN_THRESHOLD_CORR", 0.5, 0, 1, false);//TODO

	panel.addSlider("dead zone ", "DEAD_ZONE", 3, 1, 15, true);
	panel.addSlider("min smoothing ", "MIN_SMOOTHING", 0.7, 0.1, 0.9999, false);

	panel.addToggle("template update ", "B_TEMPLATE_UPDATE", true);
	//panel.addSlider("corr diff threshold ", "CORR_DIFF_THRESHOLD", 0.2, 0, 1, false);//TODO

	panel.addToggle("calib auto return ", "B_CALIBRATION_AUTO_RETURN", true);



	if (IM.mode == INPUT_VIDEO){
		panel.setWhichPanel("video file settings");
		// TODO: add theo's video playing things.... [zach]
	} else {
		panel.setWhichPanel("live video settings");
		panel.addToggle("load video settings", "VIDEO_SETTINGS", false);
	}

    //---- button settings
	panel.setWhichPanel("button settings");
    panel.addSlider("button press time", "BUTTONPRESS_TIME", 5.0f, 0.5f, 30.0f, true);
	//panel.addToggle("double click", "B_DOUBLE_CLICK", false);//TODO

    //---- load xml settings
	panel.loadSettings("settings/trackingSettings.xml");
}

void trackingManager::updateGui(){
//�g�O���{�^����X���C�_�Őݒ肳�ꂽ�l��ϐ��ɑ������
	tracker.flip(  panel.getValueB("B_RIGHT_FLIP_X"),  panel.getValueB("B_RIGHT_FLIP_Y") );

	minBlob = panel.getValueI("MIN_BLOB");
	maxBlob = panel.getValueI("MAX_BLOB");

	threshold				= panel.getValueI("THRESHOLD_GAZE");

	tracker.gamma			= panel.getValueF("GAMMA");
	tracker.bUseGamma		= panel.getValueB("B_USE_GAMMA");

	tracker.contrast		= panel.getValueF("CONTRAST");
	tracker.brightness		= panel.getValueF("BRIGHTNESS");
	tracker.bUseContrast	= panel.getValueB("B_USE_CONTRAST");

	tracker.nDilations		= panel.getValueI("N_DILATIONS");
	tracker.bUseDilate		= panel.getValueB("B_USE_DILATE");

	int oldx				= tracker.edgeMaskStartPos.x;
	int oldy				= tracker.edgeMaskStartPos.y;
	int oldir				= tracker.edgeMaskInnerRadius;
	int oldor				= tracker.edgeMaskOuterRadius;


	tracker.edgeMaskStartPos.x		= panel.getValueI("EDGE_MASK_X");
	tracker.edgeMaskStartPos.y		= panel.getValueI("EDGE_MASK_Y");
	tracker.edgeMaskInnerRadius	= panel.getValueI("EDGE_MASK_INNER_RADIUS");
	tracker.edgeMaskOuterRadius	= panel.getValueI("EDGE_MASK_OUTER_RADIUS");


	tracker.adj_x = panel.getValueI("X_ADJUSTMENT");//TODO
	tracker.adj_y = panel.getValueI("Y_ADJUSTMENT");//TODO
	tracker.adj_scale = panel.getValueF("SCALE_ADJUSTMENT");//TODO

	tracker.target_x = panel.getValueI("X_TARGET");//TODO
	tracker.target_y = panel.getValueI("Y_TARGET");//TODO


    tracker.dead_zone=panel.getValueI("DEAD_ZONE");
    tracker.min_smoothing=panel.getValueF("MIN_SMOOTHING");


	tracker.bTemplateUpdate		= panel.getValueB("B_TEMPLATE_UPDATE");

    tracker.bCalibrationAutoReturn= panel.getValueB("B_CALIBRATION_AUTO_RETURN");


	if (	oldx	!= tracker.edgeMaskStartPos.x  ||
			oldy	!= tracker.edgeMaskStartPos.y  ||
			oldir	!= tracker.edgeMaskInnerRadius ||
			oldor	!= tracker.edgeMaskOuterRadius	){

			tracker.calculateEdgePixels();

	}


	if (IM.mode != INPUT_VIDEO){
		panel.setWhichPanel("live video settings");
		if (panel.getValueB("VIDEO_SETTINGS") == true){

#ifdef TARGET_OSX
	// since macs fuck up bad fullscreen with video settings
			ofSetFullscreen(false);
#endif
			IM.vidGrabber.videoSettings();
			panel.setValueB("VIDEO_SETTINGS", false);
		}
	}
}

void trackingManager::videoSettings(){


	// TODO: fix this!! [zach]
	//if( !bUseVideoFiles ) ((ofVideoGrabber *)videoSource)->videoSettings();

}

void trackingManager::draw(){

//    clock_t timer_n;


	ofSetColor(255,255,255);


	//�J�����摜�i����j�\���p�l���̐ݒ�------------------------------- edge
	if (panel.getSelectedPanelName() == "image adjustment" || panel.getSelectedPanelName() == "live video settings"){




        //640x480pixcel�œ����`�悷��:9�L�[�������āA�Î~����L���v�`�����邽��
        ofSetColor(255,255,255);
        //tracker.grayImgPreWarp.draw(10, 30+240*2);
        tracker.grayImgPreWarp.draw(10, 10);


	}
//�G�b�W�t�B�N�T�i�J�����摜�̈ꕔ���~�`�ɐ؂���@�A�C���C�^�ł͏d�v�ȓ������������A�C�}�E�X�ł͎g���Ă��Ȃ�
//��ʏ㍶����Q�Ԃ�


	if (panel.getSelectedPanelName() == "edge fixer"){

        int width=640;
        int height=480;


        //------------------------------------------------------
        //�G�b�W�t�B�N�T�[�ƔZ�W���z�̕`�敔���@�e���v���[�g�}�b�`���O�ȑO�Ɋዅ���W�����߂�̂Ɏg�p
        //------------------------------------------------------
		ofSetColor(255,255,255);
		//tracker.edgeMaskInverted.draw(10,10, 320, 240);
		tracker.grayImg.draw(320+20, 10, 320,240);


        //-------------------------------------------
        //�Z�W���z(x���W)
        //-------------------------------------------
        ofEnableAlphaBlending();
        ofSetColor(255, 0, 0, 120);
        for (int j = 0; j < width/2; j++){
            float pct = (float)tracker.histogram_width[2*j] / (float)tracker.maxVal_width;
            ofLine(320+20+j, 240+10, 320+20+j, 240+10 - ((1-pct)*240));

        }


        //-------------------------------------------
        //�Z�W���z(y���W)
        //-------------------------------------------
        ofEnableAlphaBlending();
        ofSetColor(255, 0, 0, 120);
        for (int j = 0; j < height/2; j++){
            float pct = (float)tracker.histogram_height[2*j] / (float)tracker.maxVal_height;
            ofLine(320+320+20, 10+j, 320+320+20 - ((1-pct)*320), 10+j );
        }


        float jy = (float)tracker.minIndex_height/2;
        float pct0 = (float)tracker.minVal_height / (float)tracker.maxVal_height;
        ofSetColor(0,0,255,120);
        ofFill();
        ofCircle(320+320+20 - ((1-pct0)*320), 10+jy, 5);


       // cout << "minVal_height:" << tracker.minVal_height << endl;



        //�e���v���[�g�}�b�`���O�A���֌W���O���t�\�����@��ʏ㍶����P�Ԗ�
        //Template matching: correlation coefficient
        //-------------------------------------------
        //int movx2=10*5+320*4;
        int movx2=10;
        int movy2=10;


        ofSetColor(255,255,255);
		ofFill();
		ofRect( movx2,movy2,320, 240);

        ofEnableAlphaBlending();
        ofSetColor(0, 0, 255,120);


        //�J��摜�̃e���v���[�g�}�b�`���O�̑��֌W���̕`�敔��
       for (int j = 1; j < width/2-1; j++){
            float pct1 = (float)tracker.corr_val[j]*200;
            float pct2 = (float)tracker.corr_val[j+1]*200;

            ofLine(movx2+j-1, movy2+240 - pct1, movx2+j, movy2+240 - pct2);
        }


        //��摜�̃e���v���[�g�}�b�`���O�̑��֌W���̕`�敔��
       ofSetColor(255,0,0);
       for (int j = 1; j < width/2-1; j++){
            float pct1 = (float)tracker.corr_D_val[j]*200;
            float pct2 = (float)tracker.corr_D_val[j+1]*200;

            ofLine(movx2+j-1, movy2+240 - pct1, movx2+j, movy2+240 - pct2);
        }


        //���֌W����1�̍����C���̕`��
        ofSetColor(0, 0, 0,120);
        float ff = 200;
        ofLine(movx2, movy2+240 - ff, 320+movx2, movy2+240 - ff);



        //�J���臒l(Open)�̗΃O���t�`��
        ofSetColor(0, 255, 0,120);
        float pct = tracker.threshold_corr_open_O*200;
        ofLine(movx2, movy2+240 - pct, 320+movx2, movy2+240 - pct);

       //�J���臒l(Closed)�̗΃O���t�`��
        ofSetColor(0, 255, 255,120);
        pct = tracker.threshold_corr_open_C*200;
        ofLine(movx2, movy2+240 - pct, 320+movx2, movy2+240 - pct);


//------------------------------------------------------
        //�J�᎞�̐g���K�[�̕`�敔���i�����痧���オ�鐂���̐��j
        ofSetColor(0, 0, 255);
        for (int j = 0; j < width/2; j++){
            int cval = tracker.click_val_blink_up_corr[j];
            ofLine(movx2+j, 240+movy2, movx2+j, 240+movy2 - 30*cval);
        }


        //�᎞�̐ԃg���K�[�̕`�敔���i�����痧���オ�鐂���̐��j
        ofSetColor(255, 0, 0);
        for (int j = 0; j < width/2; j++){
            int cval = tracker.click_val_blink_down_corr[j];
            ofLine(movx2+j, 240+movy2, movx2+j, 240+movy2 - 30*cval);
        }


        //------------------------------------------------------

        //Double Blink�̗΃g���K�[�̕`�敔���i�����痧���オ�鐂���̐��j
        ofSetColor(0, 255,0);
        for (int j = 0; j < width/2; j++){
            int cval = tracker.click_val_dbl_blink[j];
            ofLine(movx2+j, 240+movy2, movx2+j, 240+movy2 - 50*cval);
        }


        //�e���v���[�g�}�b�`���O�A���֌W���O���t�\�����@��ʏ㍶����P�Ԗځ@�����܂�


        //template_tmp.bmp�̕`�敔���@�e���v���[�g���i�����j�̕`�敔��
		ofSetColor(255,255,255);
		//tracker.grayROIImg2.draw(10, 20+240,tracker.grayROIImg2.getWidth()/2,tracker.grayROIImg2.getHeight()/2);
		tracker.grayROIImg2.draw(20+320, 20+240);


        //��e���v���[�g�摜(template_closed.bmp)�i�E��j�̕`��
		ofSetColor(255,255,255);
		tracker.grayROIImg2_C.draw(10+(10+320)*3, 10);


        //�J��e���v���[�g�摜(template.bmp)�i���j�̕`��
		ofSetColor(255,255,255);
		tracker.grayROIImg2_B.draw(10, 20+240);


        //---------------------------------------------------
        //�e���v���[�g�}�b�`���O�̌��ʕ\�����J�����摜�i����j�ɏd�˂āA�l�p�`�Ƃ��̒����̐ԓ_�_�ŕ\�����镔��
        //---------------------------------------------------
        //�E�B���h�E�T�C�Y�k���Łi1100x800�j�p�ɕύX
        int imv=-100;

		//tracker.tmpMatched_B.draw(10, 30+240*2,320,240);
		tracker.tmpMatched_B.draw(10, 30+240*2+imv,480,360);//640*3/4=480, 480*3/4=360


        int Ptx	= tracker.Tmpx3;
        int Pty	= tracker.Tmpy3;

		ofEnableAlphaBlending();
        ofSetColor(0,0,255);
        ofFill();
        ofCircle(10+Ptx*3/4, 30+240*2+Pty*3/4+imv, 3);



        Ptx	= tracker.Tmpx5;
        Pty	= tracker.Tmpy5;

		ofEnableAlphaBlending();
        ofSetColor(255,0,0);
        ofFill();
        ofCircle(10+Ptx*3/4, 30+240*2+Pty*3/4+imv, 3);




        //��e���v���[�g�̑��֌W���}�b�v��`��@�J��������̉E
		ofSetColor(255,255,255);
        tracker.corr_map_result.draw(20+480, 30+240*2+imv);




        //�㕔�̐Ԃ����ŁA��e���v���[�g�̃}�X�N�����ɂ�����X�V��~��Ԃ�ʒm
        if(tracker.bOutOfLoc){
            ofSetColor(255,0,0);
            ofRect(20+480, 30+240*2+imv-10, tracker.WW5,10);
        }





	}

	if (panel.getSelectedPanelName() == "blob detection"){

        int width=640;
        int height=480;


		ofSetColor(255,255,255);

		tracker.grayImg.draw(10+ 10 + 320, 10, 320,240);

		tracker.threshImg.draw(10 ,10,320,240);
		//tracker.contourFinder.draw(10 ,10,320,240);

	}



	if (panel.getSelectedPanelName() == "button settings"){


	}


	if (panel.getSelectedPanelName() == "video file settings"){

	}
//    tracker.grayROIImg.resetROI();


    //int yy=350;
    int yy=200;
    int xx=1020;

	ofSetColor(0, 0, 0);
	ofRect(xx,530+yy, 300,135);
	ofSetColor(255, 255, 255);
	ofDrawBitmapString("key commands: ", xx+20,550+yy);

	ofDrawBitmapString("          (f) - toggle fullscreen",			xx,550+30+yy);
	ofDrawBitmapString("     (return) - change mode",	xx,550+50+yy);
	ofDrawBitmapString("        (esc) - exit",			xx,550+70+yy);


    //float itest=777.77;
    char s1[10],s2[10],s3[10];
    sprintf(s1, "%g", tracker.ntime);


    //Blink Time
	ofSetColor(255, 255, 255);
	ofRect(1020,510, 180,100);
	ofSetColor(0, 0, 0);
    font2.drawString("Blink Time", 1025,530);
    font2.drawString(s1, 1025,560);
    font2.drawString(tracker.str, 1025,590);

    //�e���v���[�g�}�b�`���O�̑��֌W���̒l�����A���^�C���ɕ\������
	ofSetColor(255, 255, 255);
    sprintf(s2, "%g", tracker.max_val3);//�J��e���v���[�g
    sprintf(s3, "%g", tracker.max_val5);//��e���v���[�g
    font2.drawString(s2, 1025,650);
    font2.drawString(s3, 1025,680);

    //
	ofSetColor(255, 255, 255);
	if (tracker.bPleaseBlink){
		blinkInfo.draw(1025,150);

		//cout << "bPleaseBlink" << endl;
	}



    //�u�J�[�\���𕜋A���܂����v�Ƃ������i�摜�j��\������
	ofSetColor(255, 255, 255);
	if (tracker.bReturnInfo){
		returnInfo.draw(1025,150);
		//stracker.bReturnInfo=false;
	}





//----------------------------------------------

    //Top out of monitor
	ofSetColor(255, 255, 255);
	ofRect(1060,330, 60,50);

    //Left out of monitor
	ofSetColor(255, 255, 255);
	ofRect(1020,385, 60,50);

    //right out of monitor
	ofSetColor(255, 255, 255);
	ofRect(1100,385, 60,50);

    //Bottom out of monitor
	ofSetColor(255, 255, 255);
	ofRect(1060,440, 60,50);



    if (panel.getSelectedPanelName() == "button settings "){
        buttonPressTime = panel.getValueF("BUTTONPRESS_TIME");
    }

	panel.draw();
}

//--------------------------------------------------------------
float trackingManager::getButtonPressTime(){

	return buttonPressTime;

}

//--------------------------------------------------------------
void trackingManager::mouseDragged(int x, int y, int button){

	panel.mouseDragged(x, y, button);

}

//--------------------------------------------------------------
void trackingManager::mousePressed(int x, int y, int button){

	panel.mousePressed(x, y, button);
}

//--------------------------------------------------------------
void trackingManager::mouseReleased(){

	panel.mouseReleased();

}
