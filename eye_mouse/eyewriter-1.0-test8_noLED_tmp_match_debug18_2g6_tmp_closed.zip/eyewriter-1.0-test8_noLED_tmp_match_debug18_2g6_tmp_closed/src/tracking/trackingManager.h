#ifndef _TRACKSCENE_H
#define _TRACKSCENE_H


#include "ofMain.h"
#include "eyeTracker.h"
#include "ofxControlPanel.h"
#include "inputManager.h"

//#include "ofxTrueTypeFontUC.h"

class trackingManager {

	public:
		trackingManager();
		~trackingManager();

		void setup();
		void update();
		void draw();

		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased();

		void setupGui();
		void updateGui();

		void trackEyes(int width, int height);

		// open video settings panel if using a camera
		void videoSettings();

		// returns the tracked pupil centroid
		ofPoint	getEyePoint();
		bool	bGotAnEyeThisFrame();


		ofxControlPanel		panel;

		//----- video sources... what are we tracking!

		inputManager		IM;

		eyeTracker			tracker;

		int					minBlob, maxBlob;
		float				threshold;
		bool				bFoundEye;
		ofPoint				eyePoint;

        //---- button settings
        float               buttonPressTime;
        float       getButtonPressTime();



        ofTrueTypeFont font;//TODO
        ofTrueTypeFont font2;

        ofTrueTypeFont font3;


        ofImage falseImg01;
        ofImage falseImg02;
        ofImage falseImg03;
        ofImage falseImg04;
        ofImage falseImg05;
        ofImage falseImg06;
        ofImage falseImg07;
        ofImage falseImg08;
        ofImage falseImg09;

        ofImage trueImg01;
        ofImage trueImg02;
        ofImage trueImg03;
        ofImage trueImg04;
        ofImage trueImg05;
        ofImage trueImg06;
        ofImage trueImg07;
        ofImage trueImg08;
        ofImage trueImg09;


        ofImage blinkInfo;
        ofImage returnInfo;


        };

#endif
