#pragma once

#include "guiBaseObject.h"
#include "guiTypeText.h"
#include "guiColor.h"
#include "simpleColor.h"
#include "guiValue.h"

class guiTypeText : public guiBaseObject, public guiTextBase{

    public:



};
